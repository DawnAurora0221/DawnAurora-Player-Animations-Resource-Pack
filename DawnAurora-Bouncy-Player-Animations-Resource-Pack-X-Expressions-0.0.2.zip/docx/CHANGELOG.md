━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀🌪️ DawnAurora: Smooth — 更新日志全档案
DawnAurora: Smooth — Complete Changelog Archive
🌪️🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📦 当前版本 Current：Alpha 0.0.2（Death Physics / 殒落物理）
🗂️ 本文件覆盖 Coverage：Alpha 0.0.1 全量档案 + Alpha 0.0.2 增量说明
🎮 游戏版本 Game Version：1.20 ｜ 1.20.1 ｜ 1.21 ｜ 1.21.1
💻 运行端 Platform：Client-Side Only（纯客户端视觉资源包）
🧩 前置依赖 Dependencies：Entity Model Features (EMF) + Entity Texture Features (ETF)
🖥️ 推荐渲染 Recommended Stack：Iris + EMF + ETF（1.20.2+ 严禁混用 OptiFine）
📜 许可 License：DawnAurora Universal Proprietary License 1.1.0（详见 LICENSE.md）
🏷️ 项目代号 Codename：Genesis / 创世 → Alpha 0.0.2 追加代号 殒落 Deathfall

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📊 【 版本时间线 / Version Timeline 】

| 版本 | 类型 | 核心内容 | 状态 |
|---|---|---|---|
| Alpha 0.0.1 | 创世初始版 Genesis | 全量物理骨架：披风布料、鞘翅、火把、微表情、8 类状态机 | 已发布 |
| Alpha 0.0.2 | 增量版 Incremental | 移植并重制 **死亡倒地动画**，Q 弹阻尼 + 三段相位滞后 | 当前版本 ✅ |

| 文件 | 0.0.1 | 0.0.2 |
|---|---|---|
| `player.jem` | 176,625 B | 176,625 B |
| `player_slim.jem` | 174,200 B | 174,200 B |
| `player_cape.jem` | 7,247 B | 7,247 B |
| `elytra.jem` | 2,652 B | 2,652 B |

> 0.0.2 没有增加文件体积：只在两个 player jem 内部追加了 1 个变量段 + 18 条死亡通道包裹，
> 仍是单行 JSON。变量 678 → 687（+9 个 `var.dd_*`），`head` 段落 33 → 34，总段落 87 不变。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🩸 【 Alpha 0.0.2 · 死亡倒地动画 / Death Collapse Animation 】

### 🎯 为什么做这一版 / Why this release

原版 Minecraft 玩家死亡时，模型还在原地站着，瞬间僵直，没有任何倒地反馈。
0.0.1 的底层骨骼已经具备完整物理表达能力，但一直没有把 `death_time` 接进动画链，
死亡表现是空白。0.0.2 把这套补上，并且没有用「线性插值」这种偷懒做法，
而是重新搭了一套带阻尼与相位滞后的弹簧驱动。

### 🧬 底层机制 / Underlying Mechanism

CEM 内置一个只读变量 `death_time`：

```
death_time
  Type   : Float
  Values : 0.0 → 20.0
  Meaning: 实体死亡计时器，从 0 开始每刻 +1，到 20 停住（= 1 秒）
```

两个关键特性决定了实现方式：

1. **只读、不可回写**：只能用 `if(death_time > 0, ...)` 切状态，
   用 `clamp(death_time / N, 0, 1)` 归一成 0~1 的进度条。
2. **20 刻后停住**：动画必须在 20 刻内完成并收敛，否则尸体会永远僵在半空。

另外必须记死这个单位坑：

> ⚠️ **CEM 的 `rx / ry / rz` 单位是弧度（radians），不是度。**
> 写 90° 必须写成 `torad(90)`（内置函数，`torad(90) = 1.5707963`）。
> 直接把 `90` 写进 `rx` 等于 90 弧度 ≈ 5156°，模型瞬间拧成一团。
> 本包所有旋转一律走 `torad()`，请勿在任何通道里删掉它。

### 🔧 三相阻尼弹簧 / Three-Phase Damped Springs

整套死亡动作由 9 个变量驱动，其中 4 条是核心进度曲线：

| 变量 | 公式 | 相位 | 作用 |
|---|---|---|---|
| `var.dd_f` | `clamp(death_time / 11, 0, 1)` | 0 刻起 | 躯干倒地主进度，11 刻（0.55 s）触地 |
| `var.dd_q` | `(1-(1-f)³) + sin(f*540) * (1-f)² * 0.16` | 同躯干 | 减速下落 + 16% 余震 |
| `var.dd_pa` | `clamp((death_time - 1.5) / 13, 0, 1)` | 滞后 1.5 刻 | 手臂进度，甩动幅度更大 |
| `var.dd_qa` | `(1-(1-pa)²) + sin(pa*430) * (1-pa)² * 0.24` | 同手臂 | 手臂 24% 余震（肢轻、惯性小、回弹明显） |
| `var.dd_pl` | `clamp((death_time - 2.5) / 13, 0, 1)` | 滞后 2.5 刻 | 腿部进度 |
| `var.dd_ql` | `(1-(1-pl)³) + sin(pl*470) * (1-pl)² * 0.20` | 同腿 | 腿部 20% 余震，峰更陡（腿重、落地更硬） |
| `var.dd_set` | `clamp((death_time - 13) / 7, 0, 1)` | 13 刻起 | 落地余摆的启动闸门 |
| `var.dd_sway` | `sin(death_time * 26) * 0.05 * var.dd_set` | 13→20 刻 | ±3° 微余摆，7 刻内收敛到 0 |
| `var.dd_p` | `clamp(death_time / 20, 0, 1)` | 全程 | 总进度，保留给后续调参 |

**为什么是滞后链而不是同时到位**：真人倒地时躯干先失去支撑，手臂因惯性反而甩出去
（所以手臂余震百分比最高），腿最后跟上（膝先软再折）。三相位错开 1.5 刻与 2.5 刻，
就是把这个顺序做进时间轴。原版做法「所有肢体同刻线性滑到终点」完全没有这个层次。

### 📐 死亡姿态数值表 / Pose Target Table

18 个通道全部写成 `if(death_time > 0, 死亡值, 原值)`，
**不新增任何重复目标通道**（同一通道声明两次会让该通道动画失效，这是 CEM 硬约束）。

| 通道 | 死亡目标值 | 含义 |
|---|---|---|
| `body.ry` | `torad(90) * var.dd_q` | 躯干侧转 90°（倒地主轴） |
| `body.rx` | `torad(-6) * var.dd_q` | 后仰 6°，不是纯平面旋转，有体积感 |
| `body.rz` | `torad(-4) * var.dd_q` | 侧倾 4°，制造「歪倒」而非「平移」的错觉 |
| `head.ry` | `torad(90) * var.dd_q` | 头随躯干同转 90°（**关键**：不跟随会拧脖子） |
| `head.rx` | `torad(10) * var.dd_q` | 低头 10°，下巴贴胸 |
| `head.rz` | `torad(-3)*dd_q + torad(2)*dd_sway` | 侧倾 3° + 落地余摆 |
| `left_arm.rx` | `torad(-172) * var.dd_qa` | 大臂上甩 172°（原包 −180°，留 8° 防糊头） |
| `right_arm.rx` | `torad(-172) * var.dd_qa` | 同左 |
| `left_arm.ry` | `torad(90) * var.dd_qa` | 大臂沿 Y 舒展 90° |
| `right_arm.ry` | `torad(90) * var.dd_qa` | 同左（沿用原包双臂同号，保持对称） |
| `left_arm.rz` | `torad(-16) * var.dd_qa` | 左臂外张 16°，避免双臂叠成一条线 |
| `right_arm.rz` | `torad(16) * var.dd_qa` | 右臂外张 16° |
| `left_leg.ry` | `torad(90) * var.dd_ql` | 左腿外展 90° |
| `right_leg.ry` | `torad(90) * var.dd_ql` | 右腿外展 90° |
| `left_leg.rx` | `torad(6)*dd_ql + torad(6)*dd_sway` | 微屈 6° + 余摆 |
| `right_leg.rx` | `torad(6)*dd_ql - torad(6)*dd_sway` | 微屈 6° − 余摆（与左腿反相，交叉余颤） |
| `left_leg.rz` | `torad(-10) * var.dd_ql` | 左腿外撇 10° |
| `right_leg.rz` | `torad(10) * var.dd_ql` | 右腿外撇 10° |

### 🧥 图层跟随 / Layer Follow-through

12 个部件里有 6 层是衣服/皮肤层（`jacket`、`headwear`、`left_sleeve`、`right_sleeve`、
`left_pants`、`right_pants`），它们本来就写成镜像关系：

```
jacket.ry      = body.ry
headwear.rx    = head.rx
left_sleeve.rx = left_arm.rx
left_pants.ry  = left_leg.ry
```

所以**不需要**给这 6 层单独写死亡动画 —— 基础部件一动，衣层自动 1:1 跟随，
不会出现「衣服留在原地、身体倒下去」的分层撕裂。这是 0.0.1 阶段把衣层绑到母骨骼
之后，在 0.0.2 里兑现的收益。

### ⏱️ 时间轴 / Tick Timeline

```
tick 0 ─ 1.5   躯干开始失稳，手臂未动（蓄力）
tick 1.5 ─ 11  手臂甩出（dd_qa 峰值 ≈1.24 后回弹），躯干持续倒下
tick 2.5 ─ 13  腿部跟上外展，余震最晚收敛
tick 11        躯干触地（dd_f = 1），开始余震
tick 13 ─ 20   全身 ±3° 微余摆，7 刻内收敛
tick 20        完全静止，保持最终姿态
```

整条流程严格 20 刻（1 秒）内结束，不会出现「尸体永远在抖」。

### 🎛️ 调参指南 / Tuning Knobs

只动这 4 个数字，其余别碰：

| 想要的效果 | 改哪里 | 怎么改 |
|---|---|---|
| 倒得更快 | `var.dd_f` | `/ 11` → `/ 8` |
| 倒得更慢更沉 | `var.dd_f` | `/ 11` → `/ 15` |
| Q 弹更明显 | `var.dd_q` | 末尾 `* 0.16` → `* 0.26` |
| 更机械死板 | `var.dd_q` | 删掉 `+ sin(...)` 整段，只留 `(1-(1-f)³)` |
| 手臂甩更狠 | `var.dd_qa` | `* 0.24` → `* 0.34` |
| 余摆更久 | `var.dd_set` | `/ 7` → `/ 3` |
| 余摆更大 | `var.dd_sway` | `* 0.05` → `* 0.12` |
| 不要 90° 倒地 | `body.ry` 等 | `torad(90)` → `torad(75)`，**头部必须同步改** |

> ⚠️ 改角度必须成组改：`body.ry` / `head.ry` / `left_leg.ry` / `right_leg.ry` 必须同值，
> 否则躯干转 75° 头转 90°，脖子直接错位。

### ✅ 自测清单 / Self-test

1. `/gamemode survival` → `/kill @s` → F5 第三人称：应看到「侧倒 + 手臂甩开 + 腿外展 + 落地微颤」。
2. 连死 3 次，每次都在 1 秒内静止，无残留摆动。
3. 复活后走两步，走路/待机完全正常（`if` 为假时原值原样输出）。
4. 换 Alex（细臂）皮肤再死一次，确认 `player_slim.jem` 同样生效。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📖 【 Alpha 0.0.1 全量档案 / Full Archive of Alpha 0.0.1 】

### 🧾 技术总账 / Technical Ledger

| 指标 | player.jem（经典臂） | player_slim.jem（细臂） |
|---|---|---|
| 文件体积 | 176,625 B | 174,200 B |
| 骨骼 | 12 | 12 |
| 方块 | 12 | 12 |
| 动画段落 | 87（head 33 + headwear 53 + 变量段） | 87 |
| 变量 var/varb | 678 | 679 |
| 目标通道 | 645 | 645 |
| 键条数 | 1,361 | 1,362 |
| JSON 行数 | 1 行（单行压缩） | 1 行 |

| 附属文件 | 体积 | 骨骼 | 段落 | 变量 | 通道 |
|---|---|---|---|---|---|
| `player_cape.jem` | 7,247 B | 1 | 3 | 96 | 16 |
| `elytra.jem` | 2,652 B | 2 | 4 | 7 | 33 |

### 🧩 状态机矩阵 / State Machine Matrix

678 个变量按系统分组（括号内为该系统变量条数）：

| 系统 | 变量数 | 触发条件 | 表现 |
|---|---|---|---|
| 走路 walk | 43 | `limb_speed > 0` | 四肢摆动 + 躯干前倾 + 头部微摆 |
| 游泳 water | 41 | `is_swimming` | 手臂划水、身体水平漂浮 |
| 爬行 crawl | 29 | 独立计时器 | 贴地匍匐，低头抬臀 |
| 涉水 waterwalk | 27 | `fluid_depth_up > 2` | 水中行走，腿抬高、手臂后压 |
| 待机 idle | 22 | `limb_speed ≈ 0` | 呼吸微起伏 + 视线漂移 |
| 潜行 sneak | 21 | `is_sneaking` | 压低身位、步幅收窄 |
| 攀爬 climb | 21 | `is_climbing` | 四肢贴面攀附 |
| 漂浮 float | 20 | 水中静止 | 上下浮沉振荡 |
| 坠落 fall | 19 | `height_above_ground` | 四肢张开、下落加速感 |
| 攻击 punch | 19 | `swing_progress` | 主副手挥击 + 躯干扭腰 |
| 跳跃 jump | 18 | 起跳检测 | 预蹲 + 起跳伸展 |
| 燃烧 burn | 16 | `is_burning` | 抽搐、手臂乱挥 |
| 受伤 hurt | 9 | `hurt_time 10→0` | 抖动 + 头部后仰 |
| 坐下 sit | 7 | 载具/坐下 | 屈膝坐姿 |
| AFK | 7 | 静止计时器 | 长时间不动的漂移姿态 |
| 物理 physics | 6 | `physics_*` 惯性链 | 速度向量驱动的二次惯性 |
| 波形 wave | 8 | 正弦叠加 | 呼吸/待机的基础波形 |
| 死亡 death | 9 | `death_time > 0` | **0.0.2 新增** |

### 🔥 第一人称火把 / 灯笼物理

| 变量 | 作用 |
|---|---|
| `var.torch_tr` | 目标角：火把 −90°、灯笼 −38°、空手 0° |
| `var.torch_vel` | 弹簧速度项：`vel + ((tr - acc) * 45 - vel * 9) * frame_time` |
| `var.torch_acc` | 弹簧位移项：`acc + vel * frame_time` |
| `var.torch_blend` | 归一化角 `acc / 90` |
| `var.torch_amp` | 幅度包络 `abs(acc)` |
| `var.lantern` / `var.lantern_left` | 灯笼左右手独立通道 |

这是**二阶阻尼弹簧**：45 是刚度，9 是阻尼。刚度高 → 跟随快；阻尼中 → 到位轻微过冲再回稳，
这就是第一人称手臂「有重量」的来源。物品判定用
`nbt(SelectedItem.id, regex:.*torch)` / `.*lantern`，切换目标角。

### 🧥 披风布料（player_cape.jem）

| 变量族 | 作用 |
|---|---|
| 折叠位移 tx | 倒退（按 S）向内折叠，贴背不穿模 |
| 阻尼衰减 damp | 静止时抖动压到接近 0，避免旗杆式乱摆 |
| 限位 clamp | 所有旋转轴有上下限，冲刺不甩到脸上 |
| 三级 EMA | 平滑滤波，速度突变不瞬移 |

披风独立成 `player_cape.jem`，是为了兼容 Wavey Capes 这类会接管披风的模组
（EMF 特性：`player_cape.jem` 可被其它模组正确覆盖）。

### 🕊️ 鞘翅（elytra.jem）

2 骨骼、4 段落、33 通道、7 变量。地面刚性贴合背部，滑翔时翼尖高频微颤，
判定走 `is_gliding` + 高度/速度。

### 👁️ 微表情系统（headwear 53 段）

整个包里段数最多的一块：**53 个段落**，按「眼皮 / 瞳孔 / 眼白 / 眉毛 / 睫毛」五层拆分，
`right_eye` → `right_eye16` 共 16 组编号，另加 `blink13~blink20` 眨眼组。

> ⚠️ 这套系统**必须改皮肤文件**才有画面：头部贴图需预留独立眼皮图层，
> 并通过 CEM 挂载点绑定。不改皮肤，眨眼要么不显示、要么显示成错误贴图。
> 完整流程见 `USAGEGUIDE.md` 第四步。

### ⚙️ 物理惯性链

6 个 `physics_*` 变量构成「速度 → 惯性 → 姿态」的二次传导：
`physics_head_rx`、`physics_right_leg_ty`、`physics_left_leg_ty`。
配合 `var.walkage`、`var.swing_progress`、`velocity_yaw_target`、`x_pitch_target`
等渲染侧输入，实现「转身时身体滞后半拍」「落地时膝盖微压」。

### 📦 包结构

```
DawnAurora-Bouncy-Player-Animations-Resource-Pack-X-Expressions-Alpha-0.0.2.zip
├── pack.mcmeta                      ← pack_format 15 / supported_formats [15, 34]
├── pack.png                         ← 999 B / 68×48 / 24 色
├── assets/minecraft/emf/cem/
│   ├── player.jem                   ← 经典 4px 臂（Steve）
│   ├── player_slim.jem              ← 细 3px 臂（Alex）
│   ├── player_cape.jem              ← 披风布料
│   └── elytra.jem                   ← 鞘翅
├── 1-21-1/minecraft/emf/cem/        ← 1.21.1 overlay（与主目录同内容）
│   └── (同上 4 个 jem)
└── docx/
    ├── README.md
    ├── CHANGELOG.md ← 本文件
    ├── USAGEGUIDE.md
    ├── CREDITS.md
    └── LICENSE.md
```

> 📌 `player.jem` 与 `player_slim.jem` 是两套手臂模型，EMF 按皮肤模型（classic / slim）自动二选一，
> **无法合并成一个文件**，两者都必须存在。overlay 目录 `1-21-1/` 让 1.21.1 客户端读同一份内容，
> 改 jem 时两处必须同步（否则 1.21.1 会加载到旧版）。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ⚠️ 【 已知问题 / Known Issues 】

| # | 问题 | 影响 | 处置 |
|---|---|---|---|
| 1 | **593 条通道指向不存在的部件**（47 个部件名：`right_brow*`/`left_brow*` 18 组、`r_eye_top*`、`ctrl_*_pupil*`、`right_eyelid*`、`right_item`/`left_item` 等） | EMF 日志刷「找不到目标」；这些通道本身不出画面 | 0.0.1 原生结构（面部系统预留挂载点）。要彻底静默可另出「摘除死键」版本 |
| 2 | **20 个通道重复声明**（集中在 `headwear#15 / #34 / #35 / #36 / #37` 的眼部段：`l_eye_pupil2.tx`、`ctrl_r_pupil12.tx`、`right_eye12.sz` 等） | 同名通道声明两次可能让该通道动画失效 | 同上，原生结构 |
| 3 | 新增死亡变量统一 `var.dd_*` 前缀 | 无 | 与你原有 `var.dawnaurora0221_*` 不冲突 ✅ |
| 4 | `1-21-1/` overlay 需手工同步 | 忘同步会让 1.21.1 动作回退 | 每次改 jem 后两处一起替换 |

> 📌 第 1、2 条**不是 0.0.2 引入的**，0.0.1 就存在，本版未改动以保持行为一致。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🛠️ 【 安装与前置 / Install & Requirements 】

1. 安装模组 **Entity Model Features (EMF)** + **Entity Texture Features (ETF)**，缺一不可。
2. 1.20.2 及以上**严禁**同时装 OptiFine —— 会与 EMF/ETF 冲突导致模型崩溃或闪退。
3. zip 放进 `.minecraft/resourcepacks/`，进游戏启用。
4. **把本包拖到资源包列表最顶端**（优先级最高），否则被其它动作包覆盖。
5. Alex（细臂）皮肤由 EMF 自动加载 `player_slim.jem`，无需手动切。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🩺 【 排障速查 / Quick Troubleshooting 】

| 症状 | 最可能原因 | 处置 |
|---|---|---|
| 死亡时完全没反应 | `death_time` 未识别 → EMF 过旧；或其它包抢占 `player.jem` | 升级 EMF；确认包置顶 |
| 死亡时模型拧成麻花 | 某处 `torad()` 被删 | 恢复 `torad()`，CEM 旋转单位是弧度 |
| 尸体一直抖 | `dd_set` 收敛太慢 | `var.dd_set` 的 `/ 7` → `/ 4` |
| 衣服留在原地 | 衣层镜像被改坏 | 确认 `jacket.ry = body.ry` 这类行存在 |
| 死亡瞬间脖子错位 | `head.ry` 与 `body.ry` 不一致 | 两处必须同一个 `torad(N)` |
| 走路/待机异常 | 其它动作包抢占 | 本包置顶 |
| 眨眼不显示 | 没改皮肤眼皮层 | 见 USAGEGUIDE 第四步 |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ⚖️ 【 许可 / License 】

本项目适用 **DawnAurora Universal Proprietary License 1.1.0**（专有许可，非开源协议）。
完整条款见包内 `docx/LICENSE.md`。

- 🔗 官方发布源 Official Source：license.dawnaurora.dpdns.org
- 📧 书面授权通道 Licensing Contact：license@dawnaurora.dpdns.org
- 🚫 未经书面授权，禁止再分发、禁止商业使用、禁止二次修改后重新打包发布。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀 每一次倒下，也都该有重量。 / Even falling should have weight. 🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
