━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀🌪️ D A W N A U R O R A - C R E D I T S 🌪️🚀✨🌅
🩸 Alpha 0.0.2 · Death Physics / 殒落物理 🩸
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 👑🎇✨ 【 赛博创世神 · 极客殿堂 / The Cyber Creator's Hall 】 ✨🎇👑

🎇✨🌌🔥 欢迎来到 DawnAurora 的核心宇宙。这一页只写一个人 👤：
**DawnAurora0221** 🧠💪🔥 —— 所有者 👑 + 首席动画师 🎬 + 硬核物理学家 🧪 + 全栈极客 🧑‍💻。

🎇✨🌌🔥 Welcome to the core universe of DawnAurora. This page is about one person 👤:
**DawnAurora0221** 🧠💪🔥 — Owner 👑 + Lead Animator 🎬 + Hardcore Physicist 🧪 + Full-stack Geek 🧑‍💻.

| 🏷️ 字段 Field | 📦 内容 Content |
|---|---|
| 👤 署名 Credit | `DawnAurora0221` 🧬 |
| 🎭 身份 Roles | 所有者 👑 · 动画 🎬 · 物理 🧪 · 文档 📝 |
| 🧬 项目 Project | DawnAurora Player Animations（代号 🌅 Genesis / 创世） |
| 🩸 本版 Release | Alpha 0.0.2 🩸 Death Physics / 殒落物理 |
| ✍️ 包内 `credit` 字段 | `Created_By_DawnAurora0221_(Owner_&_Animator_&_Physicist)_for_DawnAurora_Player_Animations` 🔒 |
| 🔗 官方源 Official | license.dawnaurora.dpdns.org 🌐 |
| 📧 授权 Contact | license@dawnaurora.dpdns.org ✉️ |

> 🔒 包内所有 jem 的 `credit` 字段保持原样，两版均未改动，一字不动 ✅

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📦🧬 【 项目档案 / Project Profile 】 🧬📦

| 📋 项目项 | 📌 内容 |
|---|---|
| 🏷️ 全名 Full Name | 🌅 DawnAurora Bouncy Player Animations Resource Pack · X-Expressions ✨ |
| 📦 类型 Type | Minecraft Java 资源包（Resource Pack）🎨，非模组 🚫、非数据包 🚫 |
| 🎯 作用域 Scope | 纯客户端视觉层 👁️，Player 实体模型与动画 🦴，不改玩法逻辑 ⚖️ |
| ⚙️ 引擎 Engine | CEM（Custom Entity Models）🧬，由 EMF 提供解析 🔬 |
| 🧾 骨骼格式 Format | JSON（`.jem`）📄，单行压缩 📌，零换行 💯 |
| 🎮 兼容版本 Versions | 1.20 🎯 ｜ 1.20.1 🎯 ｜ 1.21 🎯 ｜ 1.21.1 🎯 |
| 🧮 pack_format | 15 ✅，`supported_formats` [15, 34] 🔢，overlay 目录 `1-21-1/` 映射 34 🔀 |
| 🦴 前置 Dependencies | EMF 🎨（Entity Model Features）+ ETF ✨（Entity Texture Features），缺一不可 ❗ |
| 🚀 加载器 Loaders | Fabric 🧵 ｜ Forge 🔨 ｜ NeoForge ☕（EMF 兼容即可 ✅） |
| 🚫 禁用 Incompatible | 1.20.2+ 与 OptiFine 混装 💀（必崩 💥） |
| 🖥️ 服务端 Server-side | 无 🚫。服务器不需要装，不参与同步 📡 |
| 📜 许可 License | DawnAurora Universal Proprietary License 1.1.0 ⚖️ |
| 🌐 官方源 Official | license.dawnaurora.dpdns.org 🔗 |
| ✉️ 联系 Contact | license@dawnaurora.dpdns.org 📧 |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🗂️💎 【 文件清单 · 逐字节 / File Manifest 】 💎🗂️

| 📄 文件 | 📏 字节 | 🦴 骨骼 | 🧊 方块 | 🎞️ 段落 | 🧮 变量 | 🔀 通道 | 🔑 键 |
|---|---|---|---|---|---|---|---|
| `player.jem` 💪 | 176,625 | 12 | 12 | 87 | 678 | 645 | 1,361 |
| `player_slim.jem` 🎯 | 174,200 | 12 | 12 | 87 | 679 | 645 | 1,362 |
| `player_cape.jem` 🧥 | 7,247 | 1 | 1 | 3 | 96 | 16 | — |
| `elytra.jem` 🕊️ | 2,652 | 2 | 2 | 4 | 7 | 33 | — |
| `pack.mcmeta` 📦 | 5,414 | — | — | — | — | — | — |
| `pack.png` 🖼️ | 999 | 68×48 像素 / 24 色 🎨 | | | | | |

**📂 目录结构 Structure：**

```
📦 assets/minecraft/emf/cem/     ← 🟢 主加载路径（1.20 / 1.20.1 / 1.21 读取）
🔀 1-21-1/minecraft/emf/cem/     ← 🔵 1.21.1 overlay（同内容，需手工同步 ⚠️）
📚 docx/                         ← README / CHANGELOG / USAGEGUIDE / CREDITS / LICENSE
```

> 📌 `player.jem`（classic，4px 臂 💪）与 `player_slim.jem`（slim，3px 臂 🎯）是两套独立手臂模型，
> EMF 按皮肤模型二选一 🔀，**无法合并 🚫**，两者必须同时存在且内容同步 ✅。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧩🔬 【 变量家族分布 · 678 个 / Variable Families 】 🔬🧩

`player.jem` 共 678 个 `var.*` / `varb.*` 🧮，按系统分组 🗃️：

| 🏃 系统 System | 🔢 变量数 | 🎯 触发 / 输入 |
|---|---|---|
| 🏃 走路 walk | 43 | `limb_speed` / `limb_swing` 🦵 |
| 🏊 游泳 water | 41 | `is_swimming` / `is_in_water` 💧 |
| 🐛 爬行 crawl | 29 | 姿态判定 + 独立计时 ⏱️ |
| 🚶 涉水 waterwalk | 27 | `fluid_depth_up > 2` 🌊 |
| 😌 待机 idle | 22 | `limb_speed ≈ 0` 💤 |
| 🥷 潜行 sneak | 21 | `is_sneaking` 🕵️ |
| 🧗 攀爬 climb | 21 | `is_climbing` 🪜 |
| 🎈 漂浮 float | 20 | 水中静止 🫧 |
| 🪂 坠落 fall | 19 | `height_above_ground` 📉 |
| 👊 攻击 punch | 19 | `swing_progress` / `swing_progress2` ⚔️ |
| 🦘 跳跃 jump | 18 | 起跳检测 🚀 |
| 🔥 燃烧 burn | 16 | `is_burning` 🔥 |
| 🌊 波形 wave | 8 | 正弦叠加包络 〰️ |
| 🤕 受伤 hurt | 9 | `hurt_time` 10→0 💥 |
| 🪑 坐下 sit | 7 | 载具 / 坐下态 🛻 |
| 💤 AFK | 7 | 静止计时器 ⏳ |
| ⚙️ 物理 physics | 6 | `physics_*` 惯性链 🧲 |
| 🩸 死亡 death（0.0.2 新增 🆕） | 9 | `death_time` 0→20 💀 |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🦴🧱 【 段落与通道结构 / Segment Structure 】 🧱🦴

| 📊 指标 | 🔢 数量 |
|---|---|
| 🎬 `head` 动画段落 | 34 🆕（含 0.0.2 新增的变量段） |
| 👁️ `headwear` 动画段落 | 53（微表情系统 ✨） |
| 🎞️ 总段落 | 87 |
| 🔀 目标通道 | 645 |
| 👻 指向不存在部件的通道 | 593 条 🕳️（47 个部件名） |
| 🔁 重复声明的通道 | 20 条 🔂（`headwear#15/#34/#35/#36/#37`） |

👁️ 微表情拆层 🧬：眼皮 / 虹膜 / 眼白 / 眉毛 / 睫毛 👀，
`right_eye` → `right_eye16` 共 16 组编号 🔢，另加 `blink13` ~ `blink20` 共 8 组眨眼组 😉。
⚠️ 这部分需要皮肤文件配合 🎨（见 USAGEGUIDE 第五步 📖）。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📅🏆 【 版本记录 / Version Record 】 🏆📅

### 🌅 Alpha 0.0.1 — Genesis / 创世

| 📋 项目 | 📌 内容 |
|---|---|
| ✅ 交付内容 | 全套 CEM 骨骼 🦴 与 18 套状态机 🏃；披风布料 🧥；鞘翅 🕊️；第一人称火把与灯笼 🔥；微表情层 👁️ |
| 📊 技术规模 | 12 骨骼 / 12 方块 / 87 段 / 678 变量 / 645 通道 / 1,361 键 💯 |
| ⚠️ 已知遗留 | 593 条死键 🕳️、20 条重复声明 🔁（本版即存在，未清理 🚫） |
| 🚩 状态 | 已发布 ✅ |

### 🩸 Alpha 0.0.2 — Death Physics / 殒落物理

| 📋 项目 | 📌 内容 |
|---|---|
| ✅ 交付内容 | 死亡倒地动画 🩸，接入 `death_time` ⏱️，三相阻尼弹簧 🌀 + 相位滞后 ⏳ + 落地余摆 🌊 |
| 🔢 增量 | 9 个 `var.dd_*` 变量 🧮；18 条通道就地包裹为 `if(death_time > 0, 死亡值, 原值)` 🔀 |
| 🧱 结构变化 | `head` 段落 33 → 34 🔼，总段落 87 不变 ✅；变量 678 → 687 🔢 |
| 📏 文件变化 | 4 个 jem 字节数未变 📌（单行内改写，无新增文件 🗂️） |
| 🔧 修正项 | 头部跟随躯干 👤（原实现脖子错位 💀）、手臂 −180° → −172° 🦾（留 8° 防糊头 🛡️） |
| 🚩 状态 | 当前版本 ⭐ |

> 📌 目前只有这两个版本 🗂️。0.0.2 之后的版本尚未规划、尚未命名 🚫。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 💻⚙️ 【 系统级贡献拆解 / System Breakdown 】 ⚙️💻

| 🔧 系统 | 🧬 实现要点 | 📊 量化 |
|---|---|---|
| 🦴 骨骼矩阵 | 12 骨骼扁平化 🧱，衣层并入母骨骼 🧥，classic / slim 双模型同步 🔀 | 24 方块 / 2 套 💯 |
| 🧥 衣层跟随 | 6 层衣部件写成镜像表达式 🔁，母骨骼一动即 1:1 跟随 ✅ | 36 行镜像 |
| 🧥 披风布料 | 折叠位移 tx 📐、多轴阻尼 📉、全轴 clamp 限位 🛑、三级 EMA 滤波 🧲 | 96 变量 / 16 通道 |
| 🕊️ 鞘翅 | 地面刚性贴合 🗿 + 滑翔翼尖微颤 🪂 | 7 变量 / 33 通道 |
| 🔥 第一人称火把 | 二阶阻尼弹簧 🌀（刚度 45 / 阻尼 9 ⚖️），火把 −90° 💡、灯笼 −38° 🏮，`nbt` 识别物品 🔍 | 6 组 torch / lantern 变量 |
| 👁️ 微表情 | 五层拆分 🧬 + 16 组眼部编号 🔢 + 8 组眨眼 😉 | `headwear` 53 段 |
| 🏃 状态机 | 18 套互斥判定 ⚖️，`frame_time` 平滑 🧈，clamp 收敛 🛑 | 678 变量 |
| ⚙️ 物理惯性 | 速度 → 惯性 → 姿态 二级传导 🧲 | 6 个 `physics_*` |
| 🩸 死亡倒地（0.0.2 🆕） | 三相阻尼弹簧 🌀 + 1.5 / 2.5 刻相位滞后 ⏳ + 13 刻后余摆收敛 🌊 | 9 变量 / 18 通道 / 20 刻 |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧱🚧 【 硬性约束 · 违反即崩 / Hard Constraints 】 🚧🧱

⚠️ 以下全是 CEM 的机制约束 🧬，不是风格偏好 🎨，违反就直接出事故 💥：

| 🛑 约束 | 📌 内容 | 💥 违反后果 |
|---|---|---|
| 📐 旋转单位 | `rx / ry / rz` 单位为**弧度** 🔄，度数必须包 `torad()` 🧮 | 直接写 90 → 90 弧度 ≈ 5156° 😱，模型扭曲 🌀 |
| 〰️ 正弦入参 | `sin()` 的入参单位是**度** 🎯 | 传入弧度值会导致抖动频率失真 📉 |
| 🔀 通道唯一 | 同一目标通道只能声明一次 ☝️ | 声明两次会让该通道动画失效 🚫 |
| 🧥 衣层镜像 | `jacket.ry = body.ry` 这类镜像行必须存在 ✅ | 衣服留在原地 👕，出现分层撕裂 💔 |
| 💪 模型二分 | classic / slim 两套模型不能合并 🚫 | 细臂皮肤加载到粗臂模型，手臂穿模 🕳️ |
| 📂 目录同步 | `assets/` 与 `1-21-1/` 两处 jem 必须一致 🔁 | 1.21.1 客户端加载旧版，动作回退 ⏪ |
| ⏱️ 时序收敛 | `death_time` 在 20 刻后停住 🛑 | 未在 20 刻收敛的动画会永久僵在半空 🧟 |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ⚠️🕳️ 【 已知问题 / Known Issues 】 🕳️⚠️

| #️⃣ | 🕳️ 问题 | 💥 影响 | 🏷️ 来源 |
|---|---|---|---|
| 1️⃣ | 593 条通道指向不存在的部件 🕳️（47 个部件名：`right_brow`/`left_brow` 1~9、`r_eye_top*`、`ctrl_*_pupil*`、`right_eyelid*`、`right_item`/`left_item` 等） | EMF 日志提示找不到目标 📋；这些通道本身不出画面 🚫 | 0.0.1 原生 🧬 |
| 2️⃣ | 20 条通道重复声明 🔁（集中在 `headwear#15/#34/#35/#36/#37`：`l_eye_pupil2.tx`、`ctrl_r_pupil12.tx`、`right_eye12.sz` 等） | 该通道动画可能失效 💀 | 0.0.1 原生 🧬 |
| 3️⃣ | 微表情依赖改皮肤 🎨 | 不改皮肤 → 不眨眼 👁️ | 设计如此 ✅ |
| 4️⃣ | `1-21-1/` overlay 需手工同步 🔁 | 忘同步 → 1.21.1 动作回退 ⏪ | 打包流程 📦 |

> 📌 第 1、2 条在 0.0.1 就存在 🧬，0.0.2 未改动 ✅，保持行为一致 ⚖️。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧪🔬 【 验证方法 / How Verified 】 🔬🧪

🖥️ 本机无 Minecraft 运行环境 🚫，所有技术结论来自文件级实测 🔍 与文档级比对 📖：

| ✅ 结论 | 🔬 验证方式 |
|---|---|
| 🔢 变量 / 段落 / 通道 / 键数量 | 直接解析 `.jem` JSON 结构计数 🧮，非估计 💯 |
| 🩸 死亡动画存在 | 全文检索 `death_time` 关键字 🔍，逐通道定位 📍 |
| 📐 弧度单位 | 比对 OptiDocs `cem_animation.html` 明文 📖（`torad` / `death_time` / `sin`） |
| 🔀 通道重复失效 | 逐段扫描重复 target key 🔁，定位到 `headwear#15` 等具体段落 📍 |
| 🕳️ 死键清单 | 提取全部 target 部件名 🏷️，与模型部件表比对求差集 ➗ |
| 🎮 运行表现 | 由使用者实机截图 / 录屏反馈 📱，再反推参数 🔄 |

> 💯 因此本项目的数字是可复算的 🧮；运行表现部分依赖实机验证 🎮。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🎯🧠 【 设计哲学 / Design Philosophy 】 🧠🎯

- 🧬 不替换皮肤文件，不强制改模型贴图，尽量用 CEM 骨骼层叠加实现动画
- 🌐 不依赖服务端，纯客户端视觉增强，服务器里也能放心用
- ⚡ 先做「灵动感」，再做「参数收敛」
- 📦 保持轻量，拒绝臃肿前置，能不用模组就不用模组
- 🎨 尊重原版美术风格，只做动作与物理层增强
- 🩸 每一个动作都要有「重量」，包括倒下
- 🕳️ 已知问题写清楚，不藏、不糊、不找借口

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ⚖️📜 【 许可 / License 】 📜⚖️

本项目适用 **DawnAurora Universal Proprietary License 1.1.0** ⚖️（专有许可 🔒，非开源 🚫）。

- ✅ 允许：个人游玩 🎮、非营利服务器 🖥️、非商业整合包引用 📦（原样文件 📌 + 显著署名 🏷️ + 免费 💰🚫）
- ❌ 禁止：再分发 🚫、修改后发布 🛠️、商业使用 💰、AI 训练 🤖、抽取资产 🧲、移除署名 🚫
- 📧 书面授权通道：license@dawnaurora.dpdns.org ✉️
- 🔗 完整条款：`docx/LICENSE.md` 📄 或 license.dawnaurora.dpdns.org 🌐

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 💬🔥 【 开发者宣言 / The Geek's Manifesto 】 🔥💬

> 🩸 我不做「看起来会动」的动画，我做「看起来有重量」的动画。
> ⚖️ 一帧里差的不是 5°，是有没有人在后面推你。

> 🩸 I don't make animations that merely move. I make animations that carry weight.
> ⚖️ The difference is not 5 degrees — it is whether something is pushing you.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀 DawnAurora0221 🧠💪🔥 · Genesis 🌅 创世 · Alpha 0.0.2 🩸 · Deathfall 💀 殒落 🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
