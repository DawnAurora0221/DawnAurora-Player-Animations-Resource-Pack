━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀🌪️ D A W N A U R O R A - R E A D M E 🌪️🚀✨🌅
DawnAurora: Smooth — X-Expressions Alpha · 0.0.2
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[![GitHub Stars](https://img.shields.io/badge/GitHub-DawnAurora0221%2FDawnAurora_Player_Animation-ffb86c?style=for-the-badge&logo=github)](https://github.com/DawnAurora0221/DawnAurora_Player_Animation)
[![License](https://img.shields.io/badge/License-DawnAurora_Universal_Proprietary_1.1.0-8be9fd?style=for-the-badge&logo=shield)](https://license.dawnaurora.dpdns.org)
[![Official Source](https://img.shields.io/badge/Official_Source-license.dawnaurora.dpdns.org-50fa7b?style=for-the-badge&logo=firefox)](https://license.dawnaurora.dpdns.org)
[![Licensing Contact](https://img.shields.io/badge/Licensing-license%40dawnaurora.dpdns.org-ff79c6?style=for-the-badge&logo=maildotru)](mailto:license@dawnaurora.dpdns.org)
[![Minecraft Version](https://img.shields.io/badge/Minecraft-Java_1.20~1.21.1-50fa7b?style=for-the-badge&logo=minecraft)](https://www.minecraft.net/)
[![Requires EMF+ETF](https://img.shields.io/badge/Requires-EMF_%2B_ETF-ff79c6?style=for-the-badge)](https://modrinth.com/mod/entity-model-features)
[![Client Side Only](https://img.shields.io/badge/Scope-Client_Side_Only-bd93f9?style=for-the-badge)]()
[![Death Animation](https://img.shields.io/badge/0.0.2-Death_Physics-ff5555?style=for-the-badge)]()

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 👑🎇✨ 【 赛博创世神 · 极客殿堂 / The Cyber Creator's Hall 】 ✨🎇👑

🎇✨🌌🔥 欢迎来到 DawnAurora 的核心宇宙。这不是一份普通的材质包 📦🪶，
这是一场由 1,361 条动画键 ⚙️、678 个物理变量 🧮 与纯手搓 CEM 骨骼矩阵 🦴
堆出来的玩家物理革命 💥🌪️。

Welcome to the core universe of DawnAurora. This is NOT an ordinary texture pack 📦🪶 —
it is a player-physics revolution built from 1,361 animation keys ⚙️, 678 physics
variables 🧮 and a 100% hand-crafted CEM skeleton matrix 🦴. 💥🌍

本包依托 **EMF & ETF** 渲染框架 🎨✨，不依赖任何动作模组 🚫，直接给史蒂夫与艾利克斯 💪
加上重量感 ⚖️、布料惯性 🧥、气流反馈 🌪️ 与微表情 👁️‍🗨️😉，并且——
**在 0.0.2 里补上了原本缺失的死亡倒地动画** 🩸。

Built on the **EMF & ETF** framework with zero animation mods, it gives Steve and Alex
real weight, cloth inertia, airflow response and micro-expressions 👁️‍🗨️😉 — and
**Alpha 0.0.2 finally adds the missing death collapse animation** 🩸.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📦 【 项目基础档案 / Project Profile 】

| 项目 | 内容 |
|---|---|
| 🧪 发布版本 Release | **Alpha 0.0.2 — Death Physics / 殒落物理** |
| 🎮 兼容版本 Game Version | 1.20 ｜ 1.20.1 ｜ 1.21 ｜ 1.21.1 |
| 🧩 前置依赖 Dependencies | Entity Model Features (EMF) + Entity Texture Features (ETF) |
| 🖥️ 运行模式 Platform | Client-Side Only 纯客户端视觉效果 |
| 📁 包体结构 | 4 个 jem × 2 目录（主目录 + `1-21-1` overlay）+ docx 文档 |
| 🦴 骨骼规模 | 12 骨骼 / 12 方块 / 87 动画段落 |
| 🧮 变量规模 | 678 个物理变量 / 645 个目标通道 |
| 🔥 核心数据量 | 1,361 条动画键（player.jem） |
| 📜 许可 License | DawnAurora Universal Proprietary License 1.1.0 |
| 🔗 官方发布源 | license.dawnaurora.dpdns.org |
| 📧 授权联系 | license@dawnaurora.dpdns.org |
| 🏷️ 项目代号 Codename | Genesis / 创世 → Deathfall / 殒落 |
| 🌐 适用场景 | 单人、多人服务器、整合包、视频展示 |
| 📮 反馈渠道 | 通过官方发布源公布的联系方式提交 |
| 🚫 商业使用 | 严格禁止（详见 LICENSE.md） |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ✨ 【 核心亮点 / Core Highlights 】

### 🩸 0.0.2 新增：死亡倒地物理 / Death Collapse

原版玩家死亡只有「站着僵住」一种表现。0.0.2 用 CEM 内置只读变量 `death_time`
（0 → 20 刻，1 秒）驱动一套**三段相位滞后的阻尼弹簧**：

| 相位 | 起点 | 肢体 | 特征 |
|---|---|---|---|
| ① 躯干 | tick 0 | `body` / `head` | 11 刻触地，余震 16% |
| ② 手臂 | tick 1.5 | `left_arm` / `right_arm` | 甩动最狠，余震 24%（肢轻惯性小） |
| ③ 腿部 | tick 2.5 | `left_leg` / `right_leg` | 最后跟上，余震 20%，峰值更陡 |

- 🌀 **Q 弹**：不是线性插值，是 `(1-(1-x)³) + sin(x*540)*(1-x)²*0.16` 这类带过冲的弹簧曲线
- 🧲 **物理**：躯干先失稳 → 手臂被惯性甩出 → 腿最后折，真人倒地的顺序
- 🌊 **顺滑**：13 刻后进入 ±3° 微余摆，7 刻内收敛，20 刻完全静止
- 🧥 **不脱层**：6 层衣部件自动 1:1 跟随母骨骼，不存在衣服留在原地
- 🎛️ **可调**：4 个数字就能改快慢与弹性（见 CHANGELOG 调参表）

### 🔥 第一人称火把 / 灯笼物理

二阶阻尼弹簧（刚度 45 / 阻尼 9），火把目标角 −90°、灯笼 −38°，
`nbt(SelectedItem.id, regex:.*torch)` 识别物品后平滑切换。
手臂有重量的感觉就从这里来。

### 🧥 披风布料（player_cape.jem）

折叠位移 tx + 多轴阻尼 + 全轴 clamp 限位 + 三级 EMA 滤波。
倒退时向内折叠贴背，静止时抖动压到接近 0，冲刺也不会甩到脸上。

### 🕊️ 鞘翅（elytra.jem）

2 骨骼 / 4 段落 / 33 通道 / 7 变量。地面刚性贴合，滑翔时翼尖高频微颤。

### 👁️ 微表情系统（headwear 53 段）

眼皮 / 瞳孔 / 眼白 / 眉毛 / 睫毛五层拆分，`right_eye` → `right_eye16` 共 16 组，
外加 `blink13~blink20` 眨眼组。

> ⚠️ 必须改皮肤文件（头区预留独立眼皮图层 + CEM 挂载点绑定），否则不显示或显示错误贴图。

### 🏃 状态机矩阵（18 套）

走路 43 / 游泳 41 / 爬行 29 / 涉水 27 / 待机 22 / 潜行 21 / 攀爬 21 / 漂浮 20 /
坠落 19 / 攻击 19 / 跳跃 18 / 燃烧 16 / 受伤 9 / 坐下 7 / AFK 7 / 物理 6 / 波形 8 / 死亡 9。
全部走 `clamp` 收敛与 `frame_time` 平滑，切换状态不跳帧。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 👁️‍🗨️ 【 皮肤文件修改全流程 / Skin Workflow 】

微表情系统不是「装上就生效」，它需要皮肤贴图配合。步骤：

1. **备份原皮肤**（64×64 PNG），别在原图上直接动刀。
2. 定位头部区域：`(8,8)` 到 `(16,16)` 是脸，`(40,8)` 是帽子层（headwear）。
3. 在 **headwear 层**画出「眼皮 / 眼白 / 瞳孔」的像素块，位置与脸部的眼睛像素对齐。
4. 把眼皮层用**透明像素包边**，避免眨眼时露出底色。
5. 导出 64×64 PNG，保持文件名与原皮肤一致，替换即可。
6. 进游戏确认：待机 6 秒内应出现一次眨眼；若整块黑或整块错位，说明眼皮图层坐标没对齐。

> 🧬 原理：`headwear` 层对应 CEM 的 `headwear` 骨骼，`headwear` 的 53 段动画里
> `right_eye*.sz` / `right_eyelid*.sy` 这些通道会按时间缩放该层上对应区域的像素块。
> 贴图没画 → 缩放一个空区域 → 视觉上什么都不发生。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📁 【 文件结构 / Structure 】

```
DawnAurora-Bouncy-Player-Animations-Resource-Pack-X-Expressions-Alpha-0.0.2.zip
├── pack.mcmeta                        pack_format 15 / supported_formats [15, 34]
├── pack.png                           999 B / 68×48 / 24 色
├── assets/minecraft/emf/cem/
│   ├── player.jem       176,625 B     经典臂 12 骨骼 / 87 段 / 1,361 键
│   ├── player_slim.jem  174,200 B     细臂   12 骨骼 / 87 段 / 1,362 键
│   ├── player_cape.jem    7,247 B     披风   96 变量 / 16 通道
│   └── elytra.jem         2,652 B     鞘翅   7 变量 / 33 通道
├── 1-21-1/minecraft/emf/cem/          1.21.1 overlay，与主目录同内容
│   └── (同上 4 个 jem)
└── docx/
    ├── README.md          ← 本文件
    ├── CHANGELOG.md       ← 0.0.1 全量 + 0.0.2 死亡动画详解
    ├── USAGEGUIDE.md      ← 安装 / 排障 / 皮肤流程
    ├── CREDITS.md         ← 作者与技术档案
    └── LICENSE.md         ← 专有许可完整条款
```

> 📌 `player.jem`（Steve，4px 臂）与 `player_slim.jem`（Alex，3px 臂）**无法合并**，
> EMF 按皮肤模型自动二选一，两者都必须存在。
> 📌 改 jem 时 `assets/` 与 `1-21-1/` **两处必须同步**，否则 1.21.1 客户端会加载旧版。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🛠️ 【 前置依赖与禁忌 / Dependencies & Warnings 】

✅ 必须：

- Entity Model Features (EMF) —— 提供 CEM 骨骼与表达式引擎
- Entity Texture Features (ETF) —— 提供自定义贴图与发光支持
- Minecraft Java 1.20 / 1.20.1 / 1.21 / 1.21.1
- Fabric / Forge / NeoForge 任意加载器

❌ 严禁：

- 1.20.2+ 同时安装 OptiFine —— 与 EMF/ETF 冲突，模型崩溃、披风僵直、严重闪退
- 用其它动作包覆盖本包的 `player.jem` —— 会顶掉全部物理效果

⚠️ 注意：

- 资源包列表里本包必须**置顶**
- 微表情需要改皮肤（见上一章）
- 死亡动画依赖 `death_time`，EMF 版本过旧时会完全无反应

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ⚠️ 【 已知问题 / Known Issues 】

| # | 问题 | 说明 |
|---|---|---|
| 1 | 593 条通道指向不存在的部件（47 个部件名，面部系统预留挂载点） | 0.0.1 原生结构，EMF 日志会提示，不影响画面；0.0.2 未改动 |
| 2 | 20 个通道重复声明（`headwear#15/#34/#35/#36/#37` 眼部段） | 同上，原生结构 |
| 3 | `1-21-1/` overlay 需手工同步 | 忘同步 → 1.21.1 版本动作回退 |
| 4 | 微表情依赖改皮肤 | 不改皮肤 → 眨眼不显示 |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📖 【 配套文档 / Document Links 】

| 文档 | 内容 |
|---|---|
| `docx/CHANGELOG.md` | 0.0.1 全量技术档案 + 0.0.2 死亡动画逐通道数值表与调参指南 |
| `docx/USAGEGUIDE.md` | 七步安装流程、视频设置、皮肤流程、排障大百科 |
| `docx/CREDITS.md` | 作者技术档案、贡献拆解、设计哲学 |
| `docx/LICENSE.md` | 专有许可完整条款与授权通道 |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 👑 【 核心开发者 / Core Developer 】

| 身份 | 署名 |
|---|---|
| 所有者 Owner | **DawnAurora0221** |
| 首席动画师 Lead Animator | **DawnAurora0221** |
| 物理系统 Physics | **DawnAurora0221** |
| 骨骼矩阵 CEM Matrix | **DawnAurora0221** |
| 文档 Docs | **DawnAurora0221** |

> 本项目的全部 CEM 骨骼、表达式、物理算法与文档均由 **DawnAurora0221** 独立手搓完成。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ⚖️ 【 许可 / License 】

本项目适用 **DawnAurora Universal Proprietary License 1.1.0**（专有许可，非开源协议）。

- ✅ 允许：个人游玩、服务器内使用、整合包内引用（保留署名与官方链接）
- ❌ 禁止：再分发原始包、商业使用、二次修改后重新打包发布、去除署名
- 📧 书面授权通道：license@dawnaurora.dpdns.org
- 🔗 完整条款：`docx/LICENSE.md` 或 license.dawnaurora.dpdns.org

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀 给方块人一点点重力，它就会活过来。 / A little gravity makes a blockman alive. 🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
