DawnAurora Player Animation - Alpha - v0.0.1
Short Name: Dapa Minecraft 1.20.1 Fabric Animation Resource Pack

📦 Version Information
Release Type: Alpha Early Preview
Supported Game Version: Minecraft 1.20.1
Requirement: Fabric Loader
Mandatory Dependencies: ETF, EMF (Fabric Mods)
✅ Completed Features
This resource pack completely overhauls vanilla Minecraft player animations, bringing smoother, more natural and detailed movement performance.

Improvements
✅ Custom idle animations
✅ Custom head yaw & pitch animations
✅ Custom running animation (default speed)
✅ Custom sprint animation
✅ Custom swimming animation
✅ Custom sneaking animation
✅ Custom prone animation
✅ Custom mount state animations
✅ Custom elytra gliding animation
✅ Custom attack / interaction animations
✅ Smooth transition between animations when equipping or using items
✅ Tight armor texture styling
Additions
✅ Walk animation (low speed)
✅ Crawl state & animations
✅ Climb state & animations
✅ Wade animation (walking in shallow water & lava)
✅ Jump, fall & land animations
✅ Water treading animation (default in-water state)
✅ Upward swimming animation
✅ Sleep animation
✅ First-person hand animations
✅ Cape animations
✅ Elytra animations
✅ Locked rotation when climbing ladders
✅ Backward walking, running, sneaking, crawling and wading animations
✅ Strafing animations for walk, run and sneak
✅ Body lean / tilt animations
🚧 Work In Progress / Planned Features
These features are under development and will be added in future updates:

⏳ Custom shield blocking animation
⏳ Equipment & hotbar swap animation
⏳ Armor state animations
⏳ Torch holding animation
⏳ Lantern holding animation
⏳ Player hurt / damage animation
⏳ Respackopts configuration support
⚠️ Important Warnings
This is a Resource Pack, Not a Mod.
ETF & EMF are strictly required. This pack uses advanced animation frameworks provided by these two mods. Animations will not load or work without them installed.
This is an Alpha test version. instability, animation glitches or frame errors may occur during use.
Client-side only. Works for single-player and multiplayer servers.
📥 Installation Guide
Install Fabric Loader for Minecraft 1.20.1
Install required dependency mods: ETF and EMF
Download the latest resource pack ZIP file from this release
Place the ZIP file into your Minecraft resourcepacks folder
Launch Minecraft, open Resource Pack settings, enable DaPa Animation Pack
Fully restart your game to apply all animation changes
📜 License
CC-BY-NC-SA 4.0 License Free for personal use, study and modification. Please retain original project credits for public distribution.

# DawnAurora Player Animation – Alpha v0.0.1

**Short Name:** Dapa  
**Game Version:** Minecraft 1.20.1  
**Loader:** Fabric  
**Type:** Animation Resource Pack  
**Mandatory Dependencies:** Entity Texture Features (ETF) + Entity Model Features (EMF)

---

##  Version Information / 版本信息

| Field | Info |
|---|---|
| Release Type | Alpha Early Preview |
| Supported Version | Minecraft 1.20.1 |
| Loader | Fabric |
| Required Mods | ETF, EMF |
| Side | Client-side only |

这是一个 **Alpha 早期预览版**，动画可能出现不稳定、错误或帧异常。  
This is an **Alpha Early Preview**. Instability, animation glitches or frame errors may occur.

---

##  Completed Features / 已完成功能

### Improvements / 优化

- Custom idle animations / 自定义待机动画
- Custom head yaw & pitch animations / 自定义头部偏航与俯仰动画
- Custom running animation (default speed) / 默认速度行走动画
- Custom sprint animation / 自定义疾跑动画
- Custom swimming animation / 自定义游泳动画
- Custom sneaking animation / 自定义潜行动画
- Custom prone animation / 自定义趴下动画
- Custom mount state animations / 自定义骑乘状态动画
- Custom elytra gliding animation / 自定义鞘翅滑翔动画
- Custom attack / interaction animations / 自定义攻击与交互动画
- Smooth animation transitions when equipping or using items / 装备或使用物品时的平滑过渡
- Tight armor texture styling / 紧身盔甲纹理风格

### Additions / 新增内容

- Low-speed walk animation / 低速行走动画
- Crawl state & animations / 爬行状态及动画
- Climb state & animations / 攀爬状态及动画
- Wade animation for shallow water & lava / 浅水与熔岩涉水动画
- Jump, fall & land animations / 跳跃、下落与落地动画
- Water treading animation as default in-water state / 水中踩踏动画（默认水中状态）
- Upward swimming animation / 向上游泳动画
- Sleep animation / 睡觉动画
- First-person hand animations / 第一人称手部动画
- Cape animations / 披风动画
- Elytra animations / 鞘翅动画
- Locked rotation when climbing ladders / 爬梯时锁定旋转
- Backward walking, running, sneaking, crawling and wading animations / 后向行走、疾跑、潜行、爬行和涉水动画
- Strafing animations for walk, run and sneak / 行走、疾跑和潜行的侧移动画
- Body lean / tilt animations / 身体倾斜与侧倾动画

---

##  Work In Progress / 开发中

- Custom shield blocking animation / 自定义盾牌格挡动画
- Equipment & hotbar swap animation / 装备与快捷栏切换动画
- Armor state animations / 盔甲状态动画
- Torch holding animation / 火把手持动画
- Lantern holding animation / 灯笼手持动画
- Player hurt / damage animation / 玩家受伤动画
- Respackopts configuration support / Respackopts 配置支持

---

## ️ Important Warnings / 重要说明

- **This is a resource pack, not a mod.**  
  这是一个资源包，不是模组。

- **ETF & EMF are strictly required.**  
  必须安装 ETF 和 EMF，否则动画不会加载。

- **Alpha Early Preview.**  
  当前为 Alpha 测试版本，可能存在不稳定、动画错误或帧异常。

- **Client-side only.**  
  仅客户端生效，可用于单人游戏和多人服务器。

- **EMF is not compatible with OptiFabric or the dorianpb CEM mod.**  
  EMF 与 OptiFabric 以及 dorianpb 版 CEM 模组不兼容。

---

##  Installation Guide / 安装方法

1. Install **Fabric Loader** for Minecraft 1.20.1.  
   为 Minecraft 1.20.1 安装 Fabric Loader。

2. Install the required dependency mods: **ETF** and **EMF**.  
   安装必需前置模组：**ETF** 和 **EMF**。

3. Download the latest resource pack ZIP file from this release.  
   从本发布页面下载最新资源包 ZIP 文件。

4. Place the ZIP file into your Minecraft `resourcepacks` folder.  
   将 ZIP 文件放入 Minecraft 的 `resourcepacks` 文件夹。

5. Launch Minecraft, open **Resource Pack** settings, and enable **DawnAurora Player Animation Pack**.  
   启动游戏，打开“资源包”设置，启用 **DawnAurora Player Animation Pack**。

6. Fully restart your game to apply all animation changes.  
   完全重启游戏以应用所有动画更改。

---

##  License / 许可

This project is licensed under **CC-BY-NC-SA 4.0**.  
本项目采用 **CC-BY-NC-SA 4.0** 许可。

Free for personal use, study and modification. Please retain original project credits for public distribution.  
允许个人使用、学习和修改。公开分发时请保留原作者署名与项目信息。

---

## Credits / 作者

Created By My Me a DawnAurora0221 for DawnAurora_Player_Animation