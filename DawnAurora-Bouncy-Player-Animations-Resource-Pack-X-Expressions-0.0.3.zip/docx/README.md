━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀🌪️ D A W N A U R O R A - R E A D M E 🌪️🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[![GitHub Stars](https://img.shields.io/badge/GitHub-DawnAurora0221%2FDawnAurora_Player_Animation-ffb86c?style=for-the-badge&logo=github)](https://github.com/DawnAurora0221/DawnAurora_Player_Animation)
[![License](https://img.shields.io/badge/License-DawnAurora_Universal_Proprietary_1.0.0-8be9fd?style=for-the-badge&logo=shield)](https://license.dawnaurora.dpdns.org)
[![Official Source](https://img.shields.io/badge/Official_Source-license.dawnaurora.dpdns.org-50fa7b?style=for-the-badge&logo=firefox)](https://license.dawnaurora.dpdns.org)
[![Licensing Contact](https://img.shields.io/badge/Licensing-license%40dawnaurora.dpdns.org-ff79c6?style=for-the-badge&logo=maildotru)](mailto:license@dawnaurora.dpdns.org)
[![Minecraft Version](https://img.shields.io/badge/Minecraft-Java_1.20~1.21.1-50fa7b?style=for-the-badge&logo=minecraft)](https://www.minecraft.net/)
[![Requires EMF+ETF](https://img.shields.io/badge/Requires-EMF_%2B_ETF-ff79c6?style=for-the-badge)](https://modrinth.com/mod/entity-model-features)
[![Client Side Only](https://img.shields.io/badge/Scope-Client_Side_Only-bd93f9?style=for-the-badge)]()
[![File Size](https://img.shields.io/badge/Size-~300KB-6272a4?style=for-the-badge)]()

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👑 【 赛博创世神 · 极客殿堂 / The Cyber Creator's Hall 】 👑
🎇✨🌌🔥 欢迎来到 DawnAurora 的绝对核心宇宙！这绝非一份普通的材质资源包 📦🪶，这是一场由无数行代码 ⚙️🧩、硬核数学算力 🧮📐 与滚烫纯粹热爱 ❤️🩸 交织淬炼而成的 MC 玩家物理革命！💥🌪️

Welcome to the absolute core universe of DawnAurora! This is NOT an ordinary texture resource pack 📦🪶, it is a player-physics revolution forged by thousands lines of code ⚙️🧩, hardcore mathematical computing power 🧮📐 and burning pure passion ❤️🩸! 💥🌍

这是一套依托 EMF & ETF 底层渲染框架、100% 纯手搓 CEM 骨骼矩阵与多轴弹簧阻尼算法的玩家物理动画资源包！告别臃肿笨重的动作模组，为史蒂夫、艾利克斯赋予真实重量感、布料惯性、气流反馈与鲜活动态微表情 👁️‍🗨️😉！

Built on EMF & ETF framework, DawnAurora is a 100% hand-crafted player physics pack with custom CEM skeleton matrices and multi-axis spring damping algorithms! No bloated animation mods needed. Grant Steve and Alex realistic weight, cloth inertia, airflow response and living micro-expressions 👁️‍🗨️😉!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 【 项目基础档案 / Project Profile 】 📦
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🧪 发布版本 Release：Alpha 创世早期测试版 Genesis Early Testing ⚗️🔬
🎮 兼容版本 Game Version：1.20 ｜ 1.20.1 ｜ 1.20.4 ｜ 1.21 ｜ 1.21.1 🎯🎮
💻 运行模式 Platform：Client-Side Only 纯客户端视觉效果 👁️‍🗨️🖥️
📁 资源包体积 File Size：🔥 极限轻量化｜约 300KB｜绝对零度掉帧 ❄️📉⚡
📜 专有许可协议 License：DawnAurora Universal Proprietary License 1.0.0 ⚖️🛡️（含书面授权通道）
🔗 官方发布源 Official Source：license.dawnaurora.dpdns.org 🌐
📮 授权联系 Licensing Contact：license@dawnaurora.dpdns.org 📧
📅 生效日期 Effective：2026年 📅
⏱️ 开发状态 Dev Status：持续迭代打磨｜Alpha 存在少量已知渲染瑕疵 🚧🔨
🧩 前置依赖 Dependencies：Entity Model Features (EMF) + Entity Texture Features (ETF) 🦴🎨
🖥️ 推荐渲染生态 Recommended Render Stack：Iris + EMF + ETF（不推荐 OptiFine）🌈
🏷️ 项目代号 Codename：Genesis / 创世 🧬
🌐 适用场景 Use Case：单人游玩、多人服务器、整合包、视频展示 🎮📺
🚫 商业使用 Commercial Use：严格禁止（详见协议章节）💰
📮 反馈渠道 Feedback：请通过官方发布源公布的联系方式提交 📬

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✨ 【 核心亮点特性 / Core Highlights 】 ✨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🧥🌪️ 多轴弹簧折叠布料物理 · 披风系统
Multi-Axis Spring Cloth Folding · Cape System

· 🛑 彻底告别糊脸穿模：重构披风受力矩阵，引入多轴阻尼衰减。站立待机时披风受重力影响死寂垂直下垂，一秒治好多动症！🚫
· 🔄 倒退折叠物理：按下 S 键倒退时，披风自动向内收缩、折叠挤压位移（TX），死死贴在后背上，绝对不乱飞！🏃‍♂️
· 🪂 真实风阻与离心力：起步、疾跑、跳跃时，披风下摆根据速度向量产生真实空气阻力，所有旋转轴全部加上 clamp 物理限位。💨
· 🧷 静止阻尼锁定：站立不动时，披风不再像旗杆一样乱摆，阻尼参数把抖动压到极低。🧘
· 🏃 疾跑尾流延展：疾跑时披风下摆向后延展，形成轻微尾流，速度感更明显。🌬️
· 🦘 跳跃惯性分离：起跳瞬间披风短暂滞后，落地后再回弹，形成自然惯性差。🪂
· 🧱 边界限位保护：所有旋转轴都加了物理限位，避免极端角度导致穿模或翻转。🔒
· 🧵 布料分层：披风内外层采用不同阻尼系数，内层贴身、外层飘逸，层次感更强。🧥
· 🌬️ 微风响应：静止状态下披风随环境产生极轻微的呼吸式浮动，不僵硬。🍃
· 🎯 参数可调：披风阻尼、弹性、限位均可后续调校，Alpha 阶段欢迎反馈。📮

🦅🪂 双重刚性空气动力学 · 鞘翅系统
Dual-Rigid Aerodynamic Elytra

· 🧬 地面刚性贴合：陆地上时鞘翅所有局部颤动被物理屏蔽，绝对不抖、不飘，死死贴住后背！🛑
· 🌪️ 滑翔翼尖后掠：起飞瞬间引入极其平滑的空气动力延展感，高频气流震颤与翼尖后掠角完美联动，俯冲时宛如猎鹰振翅！🪂
· 🪶 滑翔震颤：滑翔时鞘翅产生高频微颤，模拟真实气流对翼面的冲击。🌬️
· 🦅 俯冲收翼：俯冲时翼尖向后收拢，减少风阻，视觉上更具速度感。⚡
· 🛬 落地缓冲：落地瞬间鞘翅轻微回弹，模拟真实翼面卸力。🪂
· 🧱 刚性限位：地面状态下所有翼面旋转轴锁定，避免抖动穿模。🔒
· 🎯 参数可调：翼面阻尼、后掠角、震颤频率均可后续调校。📮

🔥💡 第一人称火把专属沉浸物理
First-Person Torch Immersive Physics

· 🌬️ 呼吸微动：站立不动时，火把随角色呼吸产生极微弱的物理正弦波浮动，连火焰的跳动都带着生命力！😮‍💨
· 🚶‍♂️ 钟摆惯性：走路时火把不再是焊死的铁棍，而是根据 limb_speed 步频产生极其真实的物理钟摆式摇晃！🏃‍♂️
· 🪂 失重与重力反馈：下坠时火把因气流向上飘，落地时重重一沉，重量感直接爆棚！🔥
· 🏃 疾跑前倾：疾跑时火把随身体前倾，产生向前惯性偏移。💨
· 🧗 攀爬摆动：攀爬时火把随手臂动作产生轻微摆动。🧗
· 🌙 静止呼吸：静止时火把随呼吸轻微起伏，节奏与角色呼吸同步。😮‍💨
· 🎯 参数可调：钟摆频率、幅度、阻尼均可后续调校。📮

👁️‍🗨️😉 动态微表情眼皮系统（需修改皮肤文件）
Dynamic Micro-Expression Eyelid System (Skin Modification Required)

⚠️ 重要说明：本系统需要你修改自己的皮肤文件，在头部区域预留独立的眼皮图层，并通过 CEM 骨骼挂载点绑定动画。不修改皮肤文件，眨眼动画不会显示，或者会显示为错误贴图。详见下方【皮肤文件修改全流程】章节。🧬

· 🔮 骨骼级挂载：在头部 CEM 骨骼挂载独立眼皮动画层，不替换原版皮肤主体。👁️
· 😉 非线性开合：快眨、慢眨、半眨三种层次，避免机械感。🎬
· ⏱️ 随机间隔：眨眼间隔随机化，避免固定节奏带来的机械感。🎲
· 🎨 皮肤图层方案：在皮肤头部区域预留上眼皮、下眼皮、闭合状态三图层。🖌️
· 🧬 对齐规则：眼皮图层中心点与头部眼睛中心点对齐，偏移量记录在案。📐
· 🛡️ Z-Fighting 规避：图层顺序与偏移设计避免闪烁。🔒
· 📋 完整流程：详见下方【皮肤文件修改全流程】，像写 Python 一样分步骤、可复现、可调试。🐍

🏃‍♂️⚙️ 全身惯性物理重写
Full-Body Physical Inertia

· 🚀 起步前倾：基于 limb_speed 变量，起步时身体自然前倾。🏃‍♂️
· 🛑 急停弹簧阻尼：急停时身体产生弹簧式回弹，不再僵硬。🧷
· 🏋️‍♂️ 落地膝盖缓冲：落地时膝盖自然弯曲缓冲，重量感更强。🦵
· 🧗 攀爬惯性：攀爬时身体随手臂动作产生轻微惯性摆动。🧗
· 🏊 游泳摆动：游泳时身体随划水动作产生自然摆动。🏊
· 🪂 坠落惯性：坠落时身体自然舒展，落地后回弹。🪂
· 🎯 参数可调：所有惯性参数均可后续调校。📮

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👁️‍🗨️ 【 皮肤文件修改全流程 / Full Skin Modification Workflow 】 👁️‍🗨️
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 整体思路（和写 Python 一样，分步骤、可复现、可调试）：
1. 🧠 先理解原理：CEM 骨骼负责“动”，皮肤文件负责“贴图”。骨骼挂载点必须指向皮肤文件中预留的眼皮图层，动画才有东西可渲染。
2. 🎨 再准备素材：在原版皮肤头部区域，额外绘制上眼皮、下眼皮、闭合状态三个图层。
3. 🧬 再绑定骨骼：在 CEM 模型文件中，把眼皮骨骼挂载到头部骨骼，并指向对应贴图坐标。
4. 🧪 最后测试：进入游戏，观察眨眼是否生效；若不生效，按排障清单逐项检查。
5. 🔁 迭代调校：根据测试结果调整眼皮图层位置、骨骼挂载点、动画参数，直到自然顺滑。

🧰 第一步：准备皮肤文件
· 📂 打开你的 Minecraft 皮肤文件（64x64 或 128x128 PNG）。🖼️
· 🧭 找到头部区域：原版皮肤头部正面在 (8,8) 到 (16,16) 区域（64x64 皮肤）。📍
· 🎨 在头部贴图的空白区域（如头部背面或侧面空白处）绘制上眼皮、下眼皮、闭合状态三张小图。🖌️
· 🧬 眼皮图层需要与头部正面眼睛位置对齐，确保骨骼挂载后能准确覆盖眼睛。🎯
· 🖌️ 上眼皮图层：绘制眼睑上半部分，闭合时向下覆盖眼睛。👁️
· 🖌️ 下眼皮图层：绘制眼睑下半部分，闭合时向上覆盖眼睛。👁️
· 🖌️ 闭合状态图层：绘制完整闭合的眼皮贴图，用于完全闭眼帧。😑
· 🧵 图层顺序：确保眼皮图层在头部图层之上，避免被头部贴图遮挡。📚
· 📐 对齐规则：眼皮图层中心点与头部眼睛中心点对齐，偏移量记录在案，供 CEM 骨骼挂载使用。📐
· 💾 保存为 PNG，保持透明通道，不要压缩。📦
· 🖼️ 建议保留原始皮肤备份，便于后续修改与回滚。💾
· 🧪 建议先在测试皮肤上试验，确认无误后再应用到正式皮肤。🧪

🧬 第二步：绑定 CEM 骨骼
· 📂 打开资源包中的 CEM 模型文件（通常是 `assets/minecraft/cem/` 下的 JSON 文件）。📄
· 🦴 找到头部骨骼（head）的挂载点。🔍
· 🧩 新增眼皮骨骼（如 `eyelid_top`、`eyelid_bottom`、`eyelid_closed`），挂载到头部骨骼下。🧬
· 🎯 将眼皮骨骼的贴图坐标指向你在皮肤文件中预留的眼皮图层。📍
· ⚙️ 设置眼皮骨骼的旋转轴与动画参数：开合角度、阻尼、延迟、随机间隔。🎛️
· 🧵 设置眼皮骨骼的层级顺序：上眼皮、下眼皮、闭合状态分别独立。📚
· 📐 设置挂载点偏移量：确保眼皮骨骼与头部眼睛位置精确对齐。📐
· ⏱️ 设置眨眼动画的随机间隔范围：如 2-6 秒随机。🎲
· 🎬 设置快眨、慢眨、半眨三种动画帧的时长与插值曲线。🎬
· 💾 保存 JSON，确保格式正确，避免语法错误导致资源包不生效。✅
· 🧪 建议先在测试资源包中验证，确认无误后再合并到正式资源包。🧪
· 📄 保留 CEM 模型文件备份，便于后续调校与回滚。💾

🧪 第三步：测试与调试
· 🎮 启动游戏，启用资源包与 EMF/ETF 前置。🚀
· 👁️ 观察角色眨眼是否生效：快眨、慢眨、半眨三种层次是否自然。🎬
· 🐛 若眨眼不生效：检查皮肤文件图层是否正确、CEM 骨骼挂载点是否指向正确、资源包是否被其他动作包覆盖。🩺
· 🎯 若眨眼位置偏移：调整眼皮图层在皮肤文件中的坐标，或调整骨骼挂载点偏移量。📐
· 🧵 若眼皮被头部遮挡：调整图层顺序，确保眼皮图层在头部图层之上。📚
· ⏱️ 若眨眼节奏僵硬：调整随机间隔范围与插值曲线。🎲
· 🎬 若眨眼动作不自然：调整快眨、慢眨、半眨的时长与阻尼。🎬
· 🔁 反复测试，直到眨眼自然顺滑，不穿模、不僵硬。💖
· 📄 记录每次调整的参数，便于后续复现与调校。📝
· 🧪 建议在单人测试世界中先验证，再应用到正式存档。🧪

📋 排障清单
· ✅ 皮肤文件是否包含眼皮图层？🖼️
· ✅ 眼皮图层是否与头部眼睛位置对齐？🎯
· ✅ 眼皮图层是否在头部图层之上？📚
· ✅ CEM 模型文件是否正确挂载眼皮骨骼？🦴
· ✅ 骨骼贴图坐标是否指向眼皮图层？📍
· ✅ 骨骼挂载点偏移量是否正确？📐
· ✅ 眨眼动画参数是否设置正确？🎛️
· ✅ 资源包是否启用在列表最顶端？📌
· ✅ EMF/ETF 是否安装且版本匹配？🧩
· ✅ 是否与其他动作包冲突？⚔️
· ✅ 游戏日志是否有资源包加载错误？📄
· ✅ 皮肤文件是否保持透明通道？🖼️
· ✅ CEM 模型文件 JSON 格式是否正确？📄
· ✅ 是否在测试世界中验证过？🧪
· ✅ 是否保留原始皮肤与 CEM 文件备份？💾

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛠️ 【 前置依赖与禁忌清单 / Dependencies & Warnings 】 🛠️
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅🦴 Entity Model Features (EMF) — 骨骼与物理演算核心
✅🎨 Entity Texture Features (ETF) — 材质、UV、眼皮渲染支撑

🔗 Modrinth 下载链接：
· https://modrinth.com/mod/entity-model-features
· https://modrinth.com/mod/entity-texture-features

❌☠️ 严禁搭配 OptiFine！底层渲染管线冲突，极易直接崩溃、动画异常！
💡🌈 推荐光影方案：Iris Shaders，完美适配整套 EMF+ETF 生态！
📦 请确保 EMF 与 ETF 版本与游戏版本匹配。🎮
🔄 如果动作不生效，请先检查前置是否安装、版本是否匹配、资源包是否启用。🩺
🧩 与其他动作包冲突时，请把 DawnAurora 放在资源包列表最顶端。📌
💾 安装前请备份存档与配置，避免意外崩溃导致数据丢失。💾
🚫 不要与同类 CEM 动作包同时启用，避免骨骼冲突。⚔️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 【 配套文档跳转 / Document Links 】 📖
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📜 CREDITS & LICENSE ｜开发团队与专有许可协议
📝 RELEASE NOTES ｜版本更新日志、特性深度解析、路线图
📗 USAGE GUIDE ｜安装教程、设置说明、排障急救百科
👁️‍🗨️ SKIN MOD GUIDE ｜皮肤文件修改全流程、CEM 骨骼绑定、排障清单
⚖️ LICENSE ｜DawnAurora Universal Proprietary License 1.0.0 完整文本
📮 LICENSING ｜书面授权申请通道与补丁审核说明

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👑 【 开发团队 / Core Development Team 】 👑
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔥 创始人兼底层物理引擎架构师 👑🧠⚡
👤 DawnAurora0221

· 🏆 职位 Role：Owner / Animator / Physicist / Protocol Architect / Release Manager
  （所有者 / 动画师 / 物理学家 / 协议架构师 / 发布管理者）
· 🧬 身份定位 Identity：DawnAurora 项目的唯一创始人、核心开发者、协议制定者与官方发布源维护者。所有底层物理逻辑、CEM 骨骼矩阵、动画参数、皮肤图层方案与授权边界，均由 DawnAurora0221 独立设计与手搓完成。🛠️
· 🎯 一句话概括 One-Liner：一个人，一台设备，一套 CEM 骨骼，一场从零手搓的物理革命。🧮🔥

🧩 技术身份 Technical Identity：
· 🦴 CEM 骨骼动画工程师：精通 Minecraft Entity Model Features 的骨骼层级、挂载点、旋转轴与动画矩阵。🦴
· ⚙️ 物理参数调校师：擅长多轴弹簧阻尼、空气动力学模拟、第一人称惯性物理、布料折叠与重力反馈。📐
· 🎨 皮肤图层设计师：设计并实现了 Expressions 微表情系统的皮肤图层方案，包括上眼皮、下眼皮、闭合状态三图层与对齐规则。🖌️
· 📜 协议架构师：独立起草并维护 DawnAurora Universal Proprietary License 1.0.0，明确授权边界、例外条款与书面授权通道。⚖️
· 🧪 测试与排障工程师：负责 Alpha 测试、崩溃日志分析、资源包冲突排查与物理参数迭代。🩺
· 📦 发布管理者：负责版本规划、官方发布源维护、更新日志撰写与社区反馈收集。📮

🛠️ 技术栈 Tech Stack：
· 🧬 CEM 骨骼动画 (Entity Model Features) 🦴
· 🎨 ETF 材质渲染 (Entity Texture Features) 🎨
· 📄 JSON 动画矩阵与模型配置 📄
· 🧮 多轴弹簧阻尼算法 (Multi-Axis Spring Damping) 📐
· 🌪️ 空气动力学模拟 (Aerodynamics Simulation) 🌬️
· 🔥 第一人称惯性物理 (First-Person Inertia Physics) 💡
· 🧵 布料折叠与阻尼锁定 (Cloth Folding & Damping Lock) 🧥
· 🖌️ 皮肤图层设计与对齐 (Skin Layer Design) 🎨
· 📦 资源包结构管理 (Resource Pack Architecture) 📦
· ⚖️ 协议文本架构 (License Text Architecture) 📜
· 🩺 崩溃日志分析与排障 (Crash Log Analysis) 🧪

💻 核心贡献 Core Contributions：
· 100% 纯手搓底层 CEM 骨骼矩阵与多轴弹簧阻尼算法，不依赖任何现成物理模组。📐
· 重写了第一人称火把惯性物理：呼吸微动、钟摆惯性、失重反馈、疾跑前倾、攀爬摆动。🔥
· 设计了披风多轴弹簧折叠布料引擎：静止阻尼锁定、倒退折叠、疾跑尾流延展、跳跃惯性分离、边界限位保护。🧥
· 实现了鞘翅双重刚性空气动力学：地面刚性贴合、滑翔翼尖后掠、俯冲收翼、落地缓冲、刚性限位。🦅
· 主导了全量动作底层物理惯性系统：起步前倾、急停弹簧阻尼、落地膝盖缓冲、攀爬惯性、游泳摆动、坠落惯性。⚙️
· 设计了 Expressions 微表情系统，并配套了完整的皮肤文件修改方案与 CEM 骨骼挂载流程。👁️
· 负责资源包整体架构、版本规划、协议边界、官方发布源维护与授权通道管理。📜
· 独立完成从概念设计、物理建模、参数调校、测试排障到发布文档的全链路工作。🧪

🎯 设计哲学 Design Philosophy：
· 🧬 能手搓就不套壳，能原生就不臃肿。🛠️
· ⚡ 先做灵动感，再做参数收敛；Alpha 阶段优先体验，后续版本逐步调校。📮
· 🌐 纯客户端视觉增强，不增加服务端负担，服务器里也能放心用。🖥️
· 🎨 尊重原版美术风格，只做动作与物理层增强，不破坏原版视觉语言。🎨
· 📜 源码可见不等于开源，作者绝对保留所有权，未明确授予的权利均予保留。⚖️
· 🚫 不靠付费墙兜售物理，不靠偷窃代码拼凑作品。🛡️
· 💖 永远免费游玩，永远尊重原创。🐾

🛡️ 协议立场 License Stance：
DawnAurora 采用 DawnAurora Universal Proprietary License 1.0.0，严禁商业倒卖、洗稿套壳、未经授权的修改发布与 AI 训练。兼容补丁、Bug 修复补丁、辅助扩展与二次开发，必须事先取得书面授权。📮

🚀 未来规划 Roadmap：
Phase 1.5 微调物理参数；Phase 2 次世代 3D 物理物品；Phase 3 原生级底层模组；Phase 4 多语言与社区生态；Phase 5 原版美术风格扩展；Phase 6 整合包友好化；Phase 7 协议与授权工具化；Phase 8 Expressions 系统扩展；Phase 9 皮肤文件工具化；Phase 10 排障工具化。🗺️

💬 极客宣言 Manifesto：
“真正的物理不应该靠付费墙来兜售，也不应该靠偷窃别人的代码来拼凑。DawnAurora 将永远免费，没有付费墙。”🛡️

📮 授权联系 Licensing Contact：license@dawnaurora.dpdns.org
🔗 官方发布源 Official Source：license.dawnaurora.dpdns.org

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚖️🛡️ 【 专有许可协议与授权边界 / Proprietary License & Authorization Boundary 】 🛡️⚖️
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📜 协议类型 License Type：DawnAurora Universal Proprietary License 1.0.0
🔗 官方发布源 Official Source：license.dawnaurora.dpdns.org
📮 授权联系 Licensing Contact：license@dawnaurora.dpdns.org
📅 生效日期 Effective：2026年

本资源包采用“源码可见”（Source-Available）与“作者绝对保留所有权”模式。源码可见不等于开源。所有未明确授予的权利均由作者 DawnAurora0221 保留。

This resource pack adopts a "Source-Available" and "Absolute Author Ownership" model. Source-Available is NOT Open Source. All rights not expressly granted are reserved by DawnAurora0221.

✅ 明确允许 Expressly Allowed：
· 🎮 个人游玩与本地使用，无需付费。
· 📦 非商业性原样分享，必须保留作者署名、本协议文件及官方发布源链接。
· 🧩 免费 Minecraft 整合包集成，整合包必须完全免费，并在鸣谢中标注 DawnAurora0221。
· 🌐 免费服务器运行未经修改的原始文件，不得设置付费墙、付费白名单或会员特权。
· 🎥 视频与直播展示，可保留平台官方广告分成，但须在简介或直播信息中注明作者及官方链接。
· 💾 个人备份与存档，仅限个人使用，不得公开分发。
· 📚 引用与评测，需署名且不得实质性替代原作品。
· 🖌️ 修改自己的皮肤文件以适配 Expressions 系统，属于个人使用范畴，允许。
· 🧪 在单人测试世界中测试资源包与皮肤修改，允许。

🚨 严禁行为 Strictly Prohibited：
· 🚫 商业倒卖：绝对禁止将本包或其任何衍生内容用于淘宝/闲鱼倒卖、付费服务器盈利、或付费整合包售卖！(NO commercial resale!)
· 🚫 洗稿套壳：绝对禁止扒取本包的物理代码、模型、贴图，改名换姓后重新发布！(NO shell-cloning!)
· 🚫 演绎修改：严禁任何未经授权的魔改、拆包、反编译、重混、移植或修改后发布！你可以自己本地用，但不能二次发布！(NO derivatives!)
· 🚫 冒充作者：严禁移除或掩盖版权声明、作者署名，严禁使用相似名称、图标、域名冒充 DawnAurora0221。
· 🚫 AI 训练：严禁将本包用于 AI/ML 训练、数据集构建、模型评估或批量抓取。
· 🚫 规避技术措施：严禁破解、绕过或移除本包的任何技术措施或版权标识。
· 🚫 违禁内容：严禁将本包用于赌博、色情、暴力、仇恨、欺诈或违反适用法律的场景。
· 🚫 竞争产品：严禁以本包为基础开发竞争性产品或服务。
· 🚫 公开分发修改后的皮肤：你可以自己修改皮肤自用，但不得将修改后的皮肤作为“DawnAurora 配套皮肤”公开发布。🖌️
· 🚫 将 Expressions 系统拆包后混入其他资源包：严禁拆包后混入自己的资源包。🧬

🛡️ 书面授权通道 Written Authorization Channel：
若你希望发布兼容补丁、Bug 修复补丁、辅助性扩展，或基于本包进行二次开发、商业使用、衍生项目发布，必须事先联系作者取得独立书面授权。未经书面授权的补丁、扩展或衍生发布，均视为严重违约与侵权。

Compatibility patches, bug-fix patches, add-ons, derivative development, and commercial use require prior written authorization from DawnAurora0221. Unauthorized patches, add-ons, or derivative publications are severe breaches.

📌 书面授权的基本条件 Conditions for Written Authorization：
· 🏷️ 必须明确标注原作者 DawnAurora0221 及官方发布源。
· 🚫 必须免费发布，不得设置付费墙、会员专属或赞助者专属。
· 🔒 不得替代、覆写或拆解本体的核心文件。
· 🧬 不得包含原版核心物理代码、模型或材质资产。
· ⚔️ 不得以本包为基础开发竞争性产品或服务。
· 📄 授权范围、期限、地域及条件以书面授权文件为准。
· 📮 授权申请需说明用途、范围、发布平台及是否涉及商业行为。
· 🛡️ 作者保留批准或拒绝的权利。

📬 如何申请授权 How to Request Authorization：
请通过官方发布源 license.dawnaurora.dpdns.org 或授权联系邮箱 license@dawnaurora.dpdns.org 提交申请，说明用途、范围、发布平台及是否涉及商业行为。作者保留批准或拒绝的权利。

For the good of DawnAurora, we welcome authorized patches and add-ons. Contact license@dawnaurora.dpdns.org before publishing. 🐾💖

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 【 未来进化路线图 / Future Roadmap 】 🚀
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

· 🩹 Phase 1.5 (Next Up)：微调物理参数，修复 Alpha 阶段的细微穿模，让布料更加自然！🛠️
· 🧊 Phase 2：3D 物理物品时代：基于 CEM 框架，手搓真正的立体护甲、灵动的动态 3D 乌龟壳，让装备也具有物理重量感！🐢🛡️
· 💻 Phase 3：26.1.2+ 原生级底层模组：彻底抛弃 EMF 前置，直接利用官方无混淆代码进行 Mixin 渲染注入，带来真正的零前置体验！🔥🤖
· 🌍 Phase 4：多语言与社区生态：支持更多语言，开放授权补丁生态。🌐
· 🎨 Phase 5：原版美术风格扩展：在保持原版风格的前提下，扩展更多动作与物理细节。🎨
· 📦 Phase 6：整合包友好化：提供更清晰的整合包集成指南与授权模板。🧩
· 🛡️ Phase 7：协议与授权工具化：提供在线授权申请与补丁审核通道。📮
· 👁️ Phase 8：Expressions 系统扩展：支持更多微表情、眼神追踪与情绪动画。😉
· 🧬 Phase 9：皮肤文件工具化：提供在线皮肤图层生成器与 CEM 骨骼绑定助手。🖌️
· 🩺 Phase 10：排障工具化：提供资源包冲突检测与崩溃日志分析工具。🧪

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💬🔥 【 开发者的极客宣言 / The Geek's Manifesto 】 💬⚡
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

“真正优秀的角色物理效果，绝不应该锁在付费墙后方售卖；更不应该依靠偷窃搬运别人的代码拼凑而成。”
"Truly great character physics should never be sold behind paywalls, nor cobbled together by stealing other creators' hard-written code."

We hand-craft every single animation frame 🖼️, every bone-transform matrix 📐, every complex mathematical iteration 🧮🔥.
我们亲手打磨每一帧动画 🖼️，手写每一组骨骼变换矩阵 📐，推演每一轮复杂数学迭代运算 🧮🔥。

DawnAurora will ALWAYS be fully free for every player. NO PAYWALLS, NO LOCKED-AWAY PREMIUM FEATURES. 🛡️✨
DawnAurora 将永久对全部玩家完全免费开放，不存在付费墙，没有被锁住的高级专属功能。

“源码可见不等于开源，尊重协议就是尊重创作。”
"Source-Available is NOT Open Source. Respecting the license is respecting creation."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💖 【 特别致谢 / Special Thanks & Shout-Outs 】 💖🌟
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

· 🌟🧵 EMF & ETF 开发团队：感谢你们提供了如此强大的底层渲染框架，让纯资源包的极致物理得以实现！🎨
· ⚙️🌐 Minecraft 极客社区：感谢所有提供 Bug 反馈、测试与支持纯原创的玩家们！🧑‍🤝‍🧑
· 👑🫡 所有拒绝套壳抄袭、坚持手写代码的 MC 原创开发者：Respect！🫡
· ☕💡 每一位熬夜测试、提交 Bug 与脑洞建议的热心玩家：你们是 DawnAurora 进化的燃料！🔥
· 🎥 所有在视频、直播中展示 DawnAurora 并标注原作者的创作者：感谢你们让更多人看到纯原创的力量！📺
· 🧩 所有遵守协议、尊重作者的整合包作者与服务器运营者：感谢你们的克制与支持！🤝
· 🌍 所有使用 Iris + EMF + ETF 生态的玩家：感谢你们拥抱更现代、更开放的渲染方案！🖥️
· 📚 所有引用、评测、报道 DawnAurora 的媒体与内容创作者：感谢你们让纯原创被更多人看见！📰
· 🖌️ 所有认真阅读皮肤文件修改流程并自行适配的玩家：感谢你们的耐心与尊重！💖
· 📮 所有通过官方渠道提交授权申请的开发者：感谢你们尊重协议边界！🛡️
· 💬 所有在社区中理性讨论、友善反馈的玩家：感谢你们让极客社区更温暖！🐾

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✨ Created with My, 💻, ☕ By DawnAurora0221. ✨
💖 Thank you for supporting 100% hand-crafted original content! / 感谢您支持百分之百纯手搓原创项目！ 💖🎉🐾
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━