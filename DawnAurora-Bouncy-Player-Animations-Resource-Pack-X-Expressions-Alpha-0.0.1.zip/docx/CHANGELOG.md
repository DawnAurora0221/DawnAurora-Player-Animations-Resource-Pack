━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀🌪️ DawnAurora Smooth - Alpha 0.0.1
创世终极物理灵动版 / Genesis Original Agile Release
🌪️🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📦 发布类型 (Release Type)：🧪 Alpha 0.0.1（Early Testing / 早期公开测试）
🎮 游戏版本 (Game Version)：1.20 ｜ 1.20.1 ｜ 1.21 ｜ 1.21.1
💻 运行端 (Platform)：Client-Side Only（纯客户端视觉资源包）
📁 资源包体积 (File Size)：极限轻量化（绝对零度掉帧 ❄️📉）
📜 专有许可协议 (License)：DawnAurora Universal Proprietary License 1.0.0 ⚖️（含书面授权通道 🛡️）
🧩 前置依赖 (Dependencies)：Entity Model Features (EMF) + Entity Texture Features (ETF)
🖥️ 推荐渲染生态 (Recommended Render Stack)：Iris + EMF + ETF（不推荐 OptiFine）
🏷️ 项目代号 (Codename)：Genesis / 创世
📅 发布阶段 (Stage)：Alpha 初始公开测试
🔧 维护状态 (Maintenance)：活跃开发中 🛠️
🌐 适用场景 (Use Case)：单人游玩、多人服务器、整合包、视频展示
🚫 商业使用 (Commercial Use)：严格禁止（详见协议章节）
📮 反馈渠道 (Feedback)：请通过官方发布源公布的联系方式提交
🔗 官方发布源 (Official Source)：license.dawnaurora.dpdns.org
📧 授权联系 (Licensing Contact)：license@dawnaurora.dpdns.org

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📖 【 版本核心概述 / Core Overview 】 📖

🎉🌟 降临了！这是 DawnAurora 历史上的绝对起点！这不仅是一个资源包，这是一场赋予 Minecraft 原版动作极致灵动与生命的奇迹！💥

在这个原初版本中，我们彻底抛弃了臃肿的模组前置，纯靠底层 CEM 骨骼手搓了全套物理引擎！从第一人称的火把呼吸，到第三人称的披风折叠，再到栩栩如生的微表情眨眼，全都在这里！🔥👁️

Welcome to the absolute starting point of DawnAurora! This is a miracle that gives vanilla animations ultimate agility and life! 🚀

⚠️ 开发者极客碎碎念 (Dev's Geek Note)：
因为这是纯手搓的 Alpha 初始版本，部分物理参数（如披风的折叠惯性）可能略微“超模”。我们在底层矩阵里注入了太多的热爱与算力，请给极客一点时间，我们会在后续版本中慢慢调校！🙇‍♂️✨

Some physics might be slightly OP. We will tune them in future updates! 🛠️

🧠 设计哲学 (Design Philosophy)：
• 不替换皮肤文件，不强制改模型贴图，尽量用 CEM 骨骼层叠加实现动画。🧬
• 不依赖服务端，纯客户端视觉增强，服务器里也能放心用。🌐
• 先做“灵动感”，再做“参数收敛”，Alpha 阶段优先体验。⚡
• 保持极限轻量，拒绝臃肿前置，能不用模组就不用模组。📦
• 尊重原版美术风格，只做动作与物理层增强，不改原版皮肤。🎨
• 所有物理参数均可后续调校，Alpha 阶段欢迎反馈。📮

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ 【 极致全新特性与底层物理深渊解析 / Extreme Features & Abyss Deep Dive 】 ✨

🧥 ▶️ 多轴弹簧折叠布料物理：披风重制
Multi-Axis Spring Cloth Folding 🌪️

· 🛑 彻底告别糊脸穿模 (No More Face Clipping)：
  彻底重构了披风受力矩阵！引入多轴阻尼衰减。站立待机时，披风受重力影响死寂垂直下垂，一秒治好多动症！🚫
· 🔄 倒退折叠物理 (Backward Folding)：
  当你按下 S 键倒退时，披风会自动向内收缩、折叠挤压位移（TX），死死贴在后背上，绝对不乱飞！🏃‍♂️
· 🪂 真实风阻与离心力 (Real Wind Resistance)：
  起步、疾跑、跳跃时，披风下摆会根据速度向量产生真实的空气阻力，所有旋转轴全部加上了 clamp 物理限位，布料质感瞬间拉满！💨
· 🧷 静止阻尼锁定 (Idle Damping Lock)：
  站立不动时，披风不再像旗杆一样乱摆，阻尼参数会把抖动压到极低。🧘
· 🏃 疾跑尾流延展 (Sprint Trail Extension)：
  疾跑时披风下摆会向后延展，形成轻微尾流，速度感更明显。🌬️
· 🦘 跳跃惯性分离 (Jump Inertia Separation)：
  起跳瞬间披风会短暂滞后，落地后再回弹，形成自然的惯性差。🪂
· 🧱 边界限位保护 (Clamp Protection)：
  所有旋转轴都加了物理限位，避免极端角度导致穿模或翻转。🔒
· 🎯 参数可调 (Tunable Parameters)：
  披风的阻尼、弹性、限位均可后续调校，Alpha 阶段欢迎反馈。📮
· 🧵 布料分层 (Cloth Layering)：
  披风内外层采用不同阻尼系数，内层贴身、外层飘逸，层次感更强。🧥
· 🌬️ 微风响应 (Breeze Response)：
  在静止状态下，披风会随环境产生极轻微的呼吸式浮动，不僵硬。🍃

🕊️ ▶️ 双重刚性空气动力学鞘翅
Dual-Rigid Aerodynamic Elytra 🦅

· 🧬 地面刚性贴合 (Rigid Ground Attachment)：
  在陆地上时，鞘翅的所有局部颤动被物理屏蔽，绝对不抖、不飘，死死贴住后背！🛑
· 🌪️ 滑翔翼尖后掠 (Swept-back Wings)：
  起飞瞬间，引入极其平滑的空气动力延展感，高频气流震颤与翼尖后掠角完美联动，俯冲时宛如猎鹰振翅！🪂
· 🪶 滑翔震颤 (Glide Flutter)：
  滑翔时鞘翅会产生高频微颤，模拟真实气流对翼面的冲击。🌬️
· 🦅 俯冲收翼 (Dive Fold)：
  俯冲时翼尖会向后收拢，减少风阻，视觉上更具速度感。⚡
· 🛬 落地缓冲 (Landing Buffer)：
  落地瞬间鞘翅会轻微回弹，模拟真实翼面卸力。🪂
· 🧱 刚性限位 (Rigid Clamp)：
  地面状态下所有翼面旋转轴锁定，避免抖动穿模。🔒

🔥 ▶️ 第一人称火把专属沉浸物理
First-Person Torch Immersive Physics 💡

· 🌬️ 呼吸微动 (Breathing Sway)：
  站立不动时，火把会随着角色的呼吸产生极其微弱的物理正弦波浮动，连火焰的跳动都带着生命力！😮‍💨
· 🚶‍♂️ 钟摆惯性 (Pendulum Inertia)：
  走路时火把不再是焊死的铁棍，而是根据 limb_speed 步频产生极其真实的物理钟摆式摇晃！🏃‍♂️
· 🪂 失重与重力反馈 (Weight & Airtime Feedback)：
  下坠时火把会因为气流向上飘，落地时重重一沉，重量感直接爆棚！🔥
· 🏃 疾跑前倾 (Sprint Lean)：
  疾跑时火把会随身体前倾，产生向前的惯性偏移。💨
· 🧗 攀爬摆动 (Climb Sway)：
  攀爬时火把会随手臂动作产生轻微摆动。🧗
· 🌙 静止呼吸 (Idle Breath)：
  静止时火把随呼吸轻微起伏，节奏与角色呼吸同步。😮‍💨
· 🎯 参数可调 (Tunable)：
  钟摆频率、幅度、阻尼均可后续调校。📮

👁️‍🗨️ ▶️ 史诗级微表情眨眼系统
Epic Smooth_Expressions System 😉

· 🔮 骨骼级挂载 (Bone-Level Attachment)：
  无需替换任何皮肤文件！直接在头部 CEM 骨骼强行挂载独立的眼皮动画层！👁️
· 😉 非线性开合 (Smooth Blinking)：
  极其微小、顺滑、带着一丝萌感的眼皮开合，让你的史蒂夫/艾里克斯拥有了真正的灵魂！💖
· 🎭 表情层次 (Expression Layers)：
  眼皮开合分为快眨、慢眨、半眨三种层次，避免机械感。🎬
· ⏱️ 随机间隔 (Random Interval)：
  眨眼间隔随机化，避免固定节奏带来的机械感。🎲
· 🧬 不替换皮肤 (No Skin Replacement)：
  完全基于 CEM 骨骼挂载，不需要替换任何皮肤文件。🧬
· 🌙 静止微动 (Idle Micro-Motion)：
  静止时眼皮会有极轻微的微动，避免“死鱼眼”。👁️

🏃‍♂️ ▶️ 全量动作底层物理惯性
Full-Body Physical Inertia ⚙️

· 🚀 起步前倾 (Start-up Lean)：
  基于 limb_speed 变量，起步时身体会自然前倾。🏃‍♂️
· 🛑 急停弹簧阻尼 (Hard-stop Spring Damping)：
  急停时身体会产生弹簧式回弹，不再僵硬。🧷
· 🏋️‍♂️ 落地膝盖缓冲 (Landing Buffer)：
  落地时膝盖会自然弯曲缓冲，重量感更强。🦵
· 🧗 攀爬惯性 (Climb Inertia)：
  攀爬时身体会随手臂动作产生轻微惯性摆动。🧗
· 🏊 游泳摆动 (Swim Sway)：
  游泳时身体会随划水动作产生自然摆动。🏊
· 🪂 坠落惯性 (Fall Inertia)：
  坠落时身体会自然舒展，落地后回弹。🪂
· 🎯 参数可调 (Tunable)：
  所有惯性参数均可后续调校。📮

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🛠️ 【 严苛的前置需求与安装避坑指南 / Strict Requirements & Install Guide 】 🛠️

❗❗❗ 必须安装的前置依赖 (MUST INSTALL Dependencies)：

· ✅ Entity Model Features (EMF) 🦴（骨骼与物理引擎的核心驱动！）
· ✅ Entity Texture Features (ETF) 🎨（材质与贴图渲染的终极支撑！）
· 🚫 如果不装前置，资源包将毫无效果！🤖
· 📦 EMF 与 ETF 请从官方渠道下载，避免第三方修改版。🔒
· 🔄 请确保 EMF 与 ETF 版本与游戏版本匹配。🎮

💥 极度危险冲突警告与设置说明 (CRITICAL WARNING)：

· 🛑 如果你使用 EMF + ETF（极力推荐）：不需要去视频设置里开启“自定义实体模型”！EMF 自带底层渲染接管，模组装好、资源包启用即自动生效！✅
· 🚫 绝对不要与 OptiFine 同时安装！底层渲染逻辑冲突会导致游戏直接崩溃（Crash）！💥
· 🌅 如果你非要用 OptiFine（老方案/不推荐）：你才需要去游戏 视频设置 -> 质量 中，手动开启“自定义实体模型 (Custom Entity Models)”，否则动作不生效！⚠️
· 🧩 与其他动作包冲突时，请把 DawnAurora 放在资源包列表最顶端。📌
· 🔍 如果动作不生效，请先检查资源包是否启用、前置是否安装、版本是否匹配。🩺
· 🚫 不要与同类 CEM 动作包同时启用，避免骨骼冲突。⚔️
· 💾 安装前请备份存档与配置，避免意外崩溃导致数据丢失。💾
· 🖥️ 推荐使用 Iris + EMF + ETF 生态，兼容性与性能更佳。🖥️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🩺 【 终极排障与急救指南 / FAQ & Troubleshooting 】 🩺

❓ Q：为什么我装了之后，史蒂夫变成了植物人/没有动作？🤖
👉 A：99.9% 是因为你装了 OptiFine 并且没开“自定义实体模型”，或者你没装 EMF/ETF。（强烈建议删掉 OptiFine，拥抱 Iris + EMF/ETF 生态！）

❓ Q：为什么披风还是会穿模/乱飞？🌪️
👉 A：请确保你使用的是最新版本。本 Alpha 版本加入了强制限位，如果你还在乱飞，说明被其他动作包覆盖了，请把 DawnAurora 放在资源包列表的最顶端！

❓ Q：我在服务器里能用吗？会崩服吗？🌐
👉 A：完全可以！本包是纯客户端视觉资源包，绝对不增加服务器负担，也不会导致崩服。

❓ Q：为什么眨眼没有生效？👁️
👉 A：请确认 EMF 已安装且版本匹配，资源包已启用，且没有被其他动作包覆盖。🩺

❓ Q：为什么火把没有物理晃动？🔥
👉 A：请确认资源包已启用，且没有被其他第一人称动作包覆盖。📌

❓ Q：我可以用在整合包里吗？🧩
👉 A：可以，但整合包必须完全免费，并在鸣谢中标注 DawnAurora0221，提供官方发布源链接。

❓ Q：我可以修改后发布吗？🛑
👉 A：不可以。本包采用专有许可协议，禁止任何形式的修改、拆包、反编译或衍生发布。如需二次开发，请先取得书面授权。

❓ Q：我可以发布兼容补丁吗？🛡️
👉 A：需事先取得书面授权。未经书面授权的补丁、扩展或衍生发布，均视为严重违约与侵权。授权联系：license@dawnaurora.dpdns.org。

❓ Q：这个包会掉帧吗？📉
👉 A：本包极限轻量，纯 CEM 骨骼动画，不增加服务端负担。实际帧率取决于设备与前置配置。🖥️

❓ Q：支持哪些游戏版本？🎮
👉 A：当前支持 1.20、1.20.1、1.21、1.21.1。后续版本会逐步适配。🔄

❓ Q：为什么我的披风在静止时还在抖？🧥
👉 A：请确认使用的是最新 Alpha 0.0.1 版本，并检查是否被其他动作包覆盖。📌

❓ Q：我可以把这个包用在付费服务器上吗？💰
👉 A：绝对不可以。本包严禁用于任何需要付费才能进入、或售卖特权的服务器。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚖️ 【 专有许可协议与授权边界（含书面授权通道） / Proprietary License & Authorization Boundary 】 ⚖️

📜 协议类型 (License Type)：DawnAurora Universal Proprietary License 1.0.0
🔗 官方发布源 (Official Source)：license.dawnaurora.dpdns.org
📮 授权联系 (Licensing Contact)：license@dawnaurora.dpdns.org
📅 生效日期 (Effective)：2026年

本资源包采用“源码可见”（Source-Available）与“作者绝对保留所有权”模式。源码可见不等于开源。所有未明确授予的权利均由作者 DawnAurora0221 保留。

This resource pack adopts a "Source-Available" and "Absolute Author Ownership" model. Source-Available is NOT Open Source. All rights not expressly granted are reserved by DawnAurora0221.

✅ 明确允许 (Expressly Allowed)：
· 🎮 个人游玩与本地使用，无需付费。
· 📦 非商业性原样分享，必须保留作者署名、本协议文件及官方发布源链接。
· 🧩 免费 Minecraft 整合包集成，整合包必须完全免费，并在鸣谢中标注 DawnAurora0221。
· 🌐 免费服务器运行未经修改的原始文件，不得设置付费墙、付费白名单或会员特权。
· 🎥 视频与直播展示，可保留平台官方广告分成，但须在简介或直播信息中注明作者及官方链接。
· 💾 个人备份与存档，仅限个人使用，不得公开分发。
· 📚 引用与评测，需署名且不得实质性替代原作品。

🚫 严格禁止 (Strictly Prohibited)：
· 🛑 任何形式的修改、拆包、反编译、重混、移植或衍生作品发布。
· 💰 任何商业使用、售卖、付费下载、付费服务器、商业托管、租赁、SaaS 或 API 包装收费。
· 🎭 移除或掩盖版权声明、作者署名，或使用相似名称、图标、域名冒充作者。
· 🤖 AI/ML 训练、批量抓取、数据集构建、规避技术措施或再许可。
· ⚠️ 将本包用于赌博、色情、暴力、仇恨、欺诈或违反适用法律的场景。
· ⚔️ 以本包为基础开发竞争性产品或服务。
· 📤 将本包文件上传至公开数据集或模型训练平台。
· 🔓 破解、绕过或移除本包的任何技术措施或版权标识。

🛡️ 书面授权通道 (Written Authorization Channel)：
若你希望发布兼容补丁、Bug 修复补丁、辅助性扩展，或基于本包进行二次开发、商业使用、衍生项目发布，必须事先联系作者取得独立书面授权。未经书面授权的补丁、扩展或衍生发布，均视为严重违约与侵权。

Compatibility patches, bug-fix patches, add-ons, derivative development, and commercial use require prior written authorization from DawnAurora0221. Unauthorized patches, add-ons, or derivative publications are severe breaches.

📌 书面授权的基本条件 (Conditions for Written Authorization)：
· 🏷️ 必须明确标注原作者 DawnAurora0221 及官方发布源。
· 🚫 必须免费发布，不得设置付费墙、会员专属或赞助者专属。
· 🔒 不得替代、覆写或拆解本体的核心文件。
· 🧬 不得包含原版核心物理代码、模型或材质资产。
· ⚔️ 不得以本包为基础开发竞争性产品或服务。
· 📄 授权范围、期限、地域及条件以书面授权文件为准。
· 📮 授权申请需说明用途、范围、发布平台及是否涉及商业行为。
· 🛡️ 作者保留批准或拒绝的权利。

📬 如何申请授权 (How to Request Authorization)：
请通过官方发布源 license.dawnaurora.dpdns.org 或授权联系邮箱 license@dawnaurora.dpdns.org 提交申请，说明用途、范围、发布平台及是否涉及商业行为。作者保留批准或拒绝的权利。

For the good of DawnAurora, we welcome authorized patches and add-ons. Contact license@dawnaurora.dpdns.org before publishing. 🐾💖

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🚀 【 未来进化路线图 / Future Roadmap 】 🚀

· 🩹 Phase 1.5 (Next Up)：微调物理参数，修复 Alpha 阶段的细微穿模，让布料更加自然！🛠️
· 🧊 Phase 2：3D 物理物品时代：基于 CEM 框架，手搓真正的立体护甲、灵动的动态 3D 乌龟壳，让装备也具有物理重量感！🐢🛡️
· 💻 Phase 3：26.1.2+ 原生级底层模组：彻底抛弃 EMF 前置，直接利用官方无混淆代码进行 Mixin 渲染注入，带来真正的零前置体验！🔥🤖
· 🌍 Phase 4：多语言与社区生态：支持更多语言，开放授权补丁生态。🌐
· 🎨 Phase 5：原版美术风格扩展：在保持原版风格的前提下，扩展更多动作与物理细节。🎨
· 📦 Phase 6：整合包友好化：提供更清晰的整合包集成指南与授权模板。🧩
· 🛡️ Phase 7：协议与授权工具化：提供在线授权申请与补丁审核通道。📮

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💖 感谢您见证 DawnAurora 的创世起点！让我们一起，把 Java 版的动作体验推向极致！🐾🚀
💖 Thank you for witnessing the genesis of DawnAurora! Let's push Java Edition animations to the absolute limit! 🐾🚀
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━