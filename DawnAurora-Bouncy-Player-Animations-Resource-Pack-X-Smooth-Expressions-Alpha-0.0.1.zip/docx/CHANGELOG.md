━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀🌪️ DawnAurora Smooth - Alpha 0.0.1 (创世终极物理灵动版 / Genesis Original Agile Release) 🌪️🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📦 发布类型 (Release Type): 🧪 Alpha 0.0.1 (Early Testing) 
🎮 游戏版本 (Game Version): 1.20 & 1.20.1 & 1.21 & 1.21.1 
💻 运行端 (Platform): Client-Side Only (纯客户端) 
📁 资源包体积 (File Size): 极限轻量化 (绝对零度掉帧 ❄️📉)
📜 开源协议 (License): CC-BY-NC-ND 4.0 ⚖️ (附带特批补丁例外条款 🛡️)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📖 【 版本核心概述 / Core Overview 】 📖

🎉🌟 降临了！这是 DawnAurora 历史上的绝对起点！这不仅是一个资源包，这是一场赋予 Minecraft 原版动作极致灵动与生命的奇迹！💥 
在这个原初版本中，我们彻底抛弃了臃肿的模组前置，纯靠底层 CEM 骨骼手搓了全套物理引擎！从第一人称的火把呼吸，到第三人称的披风折叠，再到栩栩如生的微表情眨眼，全都在这里！🔥👁️

Welcome to the absolute starting point of DawnAurora! This is a miracle that gives vanilla animations ultimate agility and life! 🚀

⚠️ 开发者极客碎碎念 (Dev's Geek Note)：因为这是纯手搓的 Alpha 初始版本，部分物理参数（如披风的折叠惯性）可能略微“超模”。我们在底层矩阵里注入了太多的热爱与算力，请给极客一点时间，我们会在后续版本中慢慢调校！🙇‍♂️✨
Some physics might be slightly OP. We will tune them in future updates! 🛠️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ 【 极致全新特性与底层物理深渊解析 / Extreme Features & Abyss Deep Dive 】 ✨

🧥 ▶️ 多轴弹簧折叠布料物理：披风重制 (Multi-Axis Spring Cloth Folding) 🌪️

· 🛑 彻底告别糊脸穿模 (No More Face Clipping)：彻底重构了披风受力矩阵！引入了多轴阻尼衰减。站立待机时，披风受重力影响死寂垂直下垂，一秒治好多动症！🚫
· 🔄 倒退折叠物理 (Backward Folding)：当你按下 S 键倒退时，披风会自动向内收缩、折叠挤压位移（TX），死死贴在后背上，绝对不乱飞！🏃‍♂️
· 🪂 真实风阻与离心力 (Real Wind Resistance)：起步、疾跑、跳跃时，披风下摆会根据速度向量产生真实的空气阻力，所有旋转轴全部加上了 clamp 物理限位，布料质感瞬间拉满！💨
· The cape hangs dead when idle, folds inward when walking backward, and NEVER flies into your face! 😎

🕊️ ▶️ 双重刚性空气动力学鞘翅 (Dual-Rigid Aerodynamic Elytra) 🦅

· 🧬 地面刚性贴合 (Rigid Ground Attachment)：在陆地上时，鞘翅的所有局部颤动被物理屏蔽，绝对不抖、不飘，死死贴住后背！🛑
· 🌪️ 滑翔翼尖后掠 (Swept-back Wings)：起飞瞬间，引入极其平滑的空气动力延展感，高频气流震颤与翼尖后掠角完美联动，俯冲时宛如猎鹰振翅！🪂
· Rigid on the ground, realistic aerodynamic flutter and swept-back wings when gliding! 🦅

🔥 ▶️ 第一人称火把专属沉浸物理 (First-Person Torch Immersive Physics) 💡

· 🌬️ 呼吸微动 (Breathing Sway)：站立不动时，火把会随着角色的呼吸产生极其微弱的物理正弦波浮动，连火焰的跳动都带着生命力！😮‍💨
· 🚶‍♂️ 钟摆惯性 (Pendulum Inertia)：走路时火把不再是焊死的铁棍，而是根据 limb_speed 步频产生极其真实的物理钟摆式摇晃！🏃‍♂️
· 🪂 失重与重力反馈 (Weight & Airtime Feedback)：下坠时火把会因为气流向上飘，落地时重重一沉，重量感直接爆棚！🔥
· Torch now has breathing sway, pendulum inertia, and weight feedback! 💡

👁️‍🗨️ ▶️ 史诗级微表情眨眼系统 (Epic Smooth_Expressions System) 😉

· 🔮 骨骼级挂载 (Bone-Level Attachment)：无需替换任何皮肤文件！直接在头部 CEM 骨骼强行挂载独立的眼皮动画层！👁️
· 😉 非线性开合 (Smooth Blinking)：极其微小、顺滑、带着一丝萌感的眼皮开合，让你的史蒂夫/艾里克斯拥有了真正的灵魂！💖
· No skin replacement needed! Blink naturally like a real living being! ✨

🏃‍♂️ ▶️ 全量动作底层物理惯性 (Full-Body Physical Inertia) ⚙️

· 基于极其精准的 limb_speed 和 fall 变量，重写了起步前倾、急停弹簧阻尼、以及落地膝盖缓冲。每一次移动都充满真实的灵动感！🚀
· Rewritten start-up lean, hard-stop spring damping, and landing buffer. Agile and real! 🏋️‍♂️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🛠️ 【 严苛的前置需求与安装避坑指南 / Strict Requirements & Install Guide 】 🛠️

❗❗❗ 必须安装的前置依赖 (MUST INSTALL Dependencies)：

· ✅ Entity Model Features (EMF) 🦴 (骨骼与物理引擎的核心驱动！)
· ✅ Entity Texture Features (ETF) 🎨 (材质与贴图渲染的终极支撑！)
· 🚫 如果不装前置，资源包将毫无效果！ 🤖

💥 极度危险冲突警告与设置说明 (CRITICAL WARNING)：

· 🛑 如果你使用 EMF + ETF (极力推荐)：不需要去视频设置里开启“自定义实体模型”！EMF 自带底层渲染接管，模组装好、资源包启用即自动生效！✅
· 🚫 绝对不要与 OptiFine 同时安装！ 底层渲染逻辑冲突会导致游戏直接崩溃（Crash）！💥
· 🌅 如果你非要用 OptiFine (老方案/不推荐)：你才需要去游戏 视频设置 -> 质量 中，手动开启 "自定义实体模型 (Custom Entity Models)"，否则动作不生效！⚠️
· DO NOT install with OptiFine! EMF/ETF users do NOT need to manually enable "Custom Entity Models" in settings, it works automatically! 🛑

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🩺 【 终极排障与急救指南 (FAQ & Troubleshooting) 】 🩺

❓ Q：为什么我装了之后，史蒂夫变成了植物人/没有动作？ 🤖
👉 A：99.9% 是因为你装了 OptiFine 并且没开“自定义实体模型”，或者你没装 EMF/ETF。（强烈建议删掉 OptiFine，拥抱 Iris + EMF/ETF 生态！）

❓ Q：为什么披风还是会穿模/乱飞？ 🌪️
👉 A：请确保你使用的是最新版本。本 Alpha 版本加入了强制限位，如果你还在乱飞，说明被其他动作包覆盖了，请把 DawnAurora 放在资源包列表的最顶端！

❓ Q：我在服务器里能用吗？会崩服吗？ 🌐
👉 A：完全可以！本包是纯客户端视觉资源包，绝对不增加服务器负担，也不会导致崩服。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚖️ 【 开源协议与神圣法则 (含特批通道) / License & Sacred Law 】 ⚖️

📜 协议类型 (License Type): CC-BY-NC-ND 4.0

为了维护纯粹的极客创作环境，本包严禁商业倒卖、洗稿套壳以及未经授权的大规模魔改发布 🛡️。但为了防止误伤热心社区，我们特别开启以下【善意补丁特批通道 (Special Patch Permission)】：

· ✅ 允许发布兼容补丁 (Compatibility Patches)：欢迎发布让 DawnAurora 与其他模组更好兼容的补丁包。
· ✅ 允许发布 Bug 修复补丁 (Bug Fix Patches)：如果你发现了代码错误并制作了修复补丁，非常欢迎你发布出来帮助大家！
· ✅ 允许发布辅助性扩展 (Add-ons)：只要是不包含原版核心物理代码、旨在辅助本包运行的附加文件。
· ⚠️ 唯一要求 (The Only Rule)：所有补丁与扩展必须明确标注原作者 DawnAurora0221，必须免费发布，且不得替代/覆写本体的核心文件。只要是为了 DawnAurora 更好（For the good of DawnAurora），我们绝对欢迎！

Special Permission Granted: You are ALLOWED to publish compatibility patches, bug fix patches, and add-ons for DawnAurora, as long as they are free, credit DawnAurora0221, and do not overwrite the core files of this project. Let's make it better together! 🐾💖

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🚀 【 未来进化路线图 / Future Roadmap 】 🚀

· 🩹 Phase 1.5 (Next Up): 微调物理参数，修复 Alpha 阶段的细微穿模，让布料更加自然！🛠️
· 🧊 Phase 2: 3D 物理物品时代：基于 CEM 框架，手搓真正的立体护甲、灵动的动态 3D 乌龟壳，让装备也具有物理重量感！🐢🛡️
· 💻 Phase 3: 26.1.2+ 原生级底层模组：彻底抛弃 EMF 前置，直接利用官方无混淆代码进行 Mixin 渲染注入，带来真正的零前置体验！🔥🤖

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💖 感谢您见证 DawnAurora 的创世起点！让我们一起，把 Java 版的动作体验推向极致！ 🐾🚀 
💖 Thank you for witnessing the genesis of DawnAurora! Let's push Java Edition animations to the absolute limit! 🐾🚀
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━