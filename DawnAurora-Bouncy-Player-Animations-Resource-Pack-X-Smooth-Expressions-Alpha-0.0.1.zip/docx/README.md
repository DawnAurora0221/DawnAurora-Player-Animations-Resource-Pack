━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀🌪️ D A W N A U R O R A - R E A D M E 🌪️🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[![GitHub Stars](https://img.shields.io/github/stars/DawnAurora0221/DawnAurora_Player_Animation?style=for-the-badge&color=ffb86c&logo=github)](https://github.com/DawnAurora0221/DawnAurora_Player_Animation)
[![License CC BY-NC-ND 4.0](https://img.shields.io/badge/License-CC--BY--NC--ND_4.0-8be9fd?style=for-the-badge)](https://creativecommons.org/licenses/by-nc-nd/4.0/)
[![Minecraft Version](https://img.shields.io/badge/Minecraft-Java_1.20~1.21.1-50fa7b?style=for-the-badge&logo=minecraft)](https://www.minecraft.net/)
[![Requires EMF+ETF](https://img.shields.io/badge/Requires-EMF_%2B_ETF-ff79c6?style=for-the-badge)](https://modrinth.com/mod/entity-model-features)
[![Client Side Only](https://img.shields.io/badge/Scope-Client_Side_Only-bd93f9?style=for-the-badge)]()
[![File Size](https://img.shields.io/badge/Size-~300KB-6272a4?style=for-the-badge)]()

👑 【 赛博创世神 · 极客殿堂 / The Cyber Creator's Hall 】 👑
🎇✨🌌🔥欢迎来到 DawnAurora 的绝对核心宇宙！这绝非一份普通的材质资源包📦🪶，这是一场由无数行代码⚙️🧩、硬核数学算力🧮📐与滚烫纯粹热爱❤️🩸交织淬炼而成的MC玩家物理革命！💥🌪️
Welcome to the absolute core universe of DawnAurora! This is NOT an ordinary texture resource pack📦🪶, it is a player‑physics revolution forged by thousands lines of code⚙️🧩, hardcore mathematical computing power🧮📐 and burning pure passion❤️🩸! 💥🌍

这是一套依托 EMF & ETF 底层渲染框架、100% 纯手搓 CEM 骨骼矩阵与多轴弹簧阻尼算法的玩家物理动画资源包！
告别臃肿笨重的动作模组，为史蒂夫、艾利克斯赋予真实重量感、布料惯性、气流反馈与鲜活动态微表情👁️‍🗨️😉！
Built on EMF & ETF framework, DawnAurora is a 100% hand‑crafted player physics pack with custom CEM skeleton matrices and multi‑axis spring damping algorithms!
No bloated animation mods needed. Grant Steve and Alex realistic weight, cloth inertia, airflow response and living micro‑expressions👁️‍🗨️😉!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 【 项目基础档案 / Project Profile 】 📦
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧪 发布版本 Release：Alpha 创世早期测试版 Genesis Early Testing ⚗️🔬
🎮 兼容版本 Game Version：1.20 / 1.20.1 / 1.20.4 / 1.21 / 1.21.1 🎯🎮
💻 运行模式 Platform：Client‑Side Only 纯客户端视觉效果 👁️‍🗨️🖥️
📁 资源包体积 File Size：🔥极限轻量化｜约 300KB｜绝对零度掉帧 ❄️📉⚡
📜 开源协议 License：CC‑BY‑NC‑ND 4.0 ⚖️🛡️（附带善意补丁特批例外条款）
⏱️ 开发状态 Dev Status：持续迭代打磨｜Alpha 存在少量已知渲染瑕疵 🚧🔨

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✨ 【 核心亮点特性 / Core Highlights 】 ✨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧥🌪️ 多轴弹簧折叠布料物理 · 披风系统
重力下垂、倒退折叠、速度驱动风阻，带角度限位防穿模，告别糊脸乱飞！
Multi-axis spring cloth cape simulation, gravity rest, backward folding, velocity wind drag, angle clamp to stop clipping!

🦅🪂 双重刚性空气动力学 · 鞘翅系统
地面刚性锁定杜绝原地抽搐，滑翔俯冲自动后掠翼尖叠加气流震颤！
Ground rigid lock to eliminate idle twitch, swept wing deformation and airflow vibration while gliding & diving!

🔥💡 第一人称火把专属沉浸物理
待机呼吸微动、奔跑钟摆摆动、下坠上浮、落地冲击，满满的重量反馈！
Idle breathing sway, pendulum swing while moving, lift on fall and heavy impact on landing!

👁️‍🗨️😉 无侵入动态微表情眨眼系统
无需修改皮肤文件，骨骼外挂眼皮动画，带Z‑Fighting规避，随机柔和眨眼！
Skin‑free bone‑mounted blinking system, Z‑fighting protection, soft randomized blink curves!

🏃‍♂️⚙️ 全身惯性物理重写
起步前倾、急停弹簧回弹、落地膝盖缓冲，每一次移动都充满血肉灵动感！
Start lean, spring‑damping stop rebound, landing knee buffer, organic full‑body inertia!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛠️ 【 前置依赖与禁忌清单 / Dependencies & Warnings 】 🛠️
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅🦴 Entity Model Features (EMF) — 骨骼与物理演算核心
✅🎨 Entity Texture Features (ETF) — 材质、UV、眼皮渲染支撑
🔗 Modrinth 下载链接：
https://modrinth.com/mod/entity-model-features
https://modrinth.com/mod/entity-texture-features

❌☠️ 严禁搭配 OptiFine！底层渲染管线冲突，极易直接崩溃、动画异常！
💡🌈 推荐光影方案：Iris Shaders，完美适配整套 EMF+ETF 生态！

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 【 配套文档跳转 / Document Links 】 📖
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📜 CREDITS & LICENSE ｜开发团队与开源神圣法则
📝 RELEASE NOTES ｜版本更新日志、特性深度解析、路线图
📗 USAGE GUIDE ｜安装教程、设置说明、排障急救百科

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👑【 开发团队 / Core Development Team 】👑
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔥 创始人兼底层物理引擎架构师 👑🧠⚡
👤 DawnAurora0221
· Owner / Animator / Physicist
· 100% 纯手搓底层 CEM 骨骼矩阵与多轴弹簧阻尼算法📐🔬
· 重写火把惯性、披风布料引擎、鞘翅空气动力学🔥🪶
· 实现无皮肤修改 Smooth_Expressions 微表情挂载系统👁️‍🗨️🎭

🧊 次世代 3D 视觉与建模大师 ⚔️🎨
👤 AuroraForge0221
· Member & Modeler
· 研发动态物理道具：立体乌龟壳🐢、分层厚重护甲🛡️、摆动饰品✨
· 高阶材质重绘、模型重塑、统一整套项目视觉风格🎞️💫

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚖️🛡️【 神圣开源法则 / The Sacred License Covenant 】🛡️⚖️
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📜 CC‑BY‑NC‑ND 4.0 署名—非商业性使用—禁止演绎 📋🔗
🚫💸 禁止商业倒卖、付费整合、盈利分发
🚫🎭 禁止扒取代码模型贴图，洗稿套壳二次发布
🚫✏️ 禁止未经授权魔改后公开发布（本地把玩OK）

✅🤝 善意补丁特批通道：
免费兼容补丁、Bug修复补丁、独立附加扩展允许发布
⚠️硬性规则：标注原作者 DawnAurora0221、完全免费、禁止覆写核心物理文件！

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💬🔥【 开发者的极客宣言 / The Geek's Manifesto 】💬⚡
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"真正优秀的角色物理效果，绝不应该锁在付费墙后方售卖；更不应该依靠偷窃搬运别人的代码拼凑而成。"
"Truly great character physics should never be sold behind paywalls, nor cobbled together by stealing other creators’ hard‑written code."

We hand‑craft every single animation frame🖼️, every bone‑transform matrix📐, every complex mathematical iteration🧮🔥.
我们亲手打磨每一帧动画🖼️，手写每一组骨骼变换矩阵📐，推演每一轮复杂数学迭代运算🧮🔥。

DawnAurora will ALWAYS be fully free for every player. NO PAYWALLS, NO LOCKED‑AWAY PREMIUM FEATURES. 🛡️✨
DawnAurora 将永久对全部玩家完全免费开放，不存在付费墙，没有被锁住的高级专属功能。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💖【 特别致谢 / Special Thanks & Shout‑Outs 】💖🌟
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌟🧵 EMF & ETF 开发团队 🎨
⚙️🌐 Minecraft 极客社区 🧑‍🤝‍🧑
👑🫡 所有拒绝套壳抄袭、坚持手写代码的MC原创开发者
☕💡 每一位熬夜测试、提交Bug与脑洞建议的热心玩家！

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✨🩸 Created with 🩸, 💻, and countless cups of ☕ By DawnAurora0221 & AuroraForge0221. ✨
💖 Thank you for supporting 100% hand‑crafted original content! / 感谢您支持百分之百纯手搓原创项目！ 💖🎉🐾
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━