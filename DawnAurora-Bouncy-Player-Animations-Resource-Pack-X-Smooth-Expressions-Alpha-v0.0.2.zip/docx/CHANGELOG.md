━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 
🌅✨🚀🌪️ DawnAurora Smooth - Alpha v0.0.2 (手臂物理集成迭代版 / Arm‑Physics Integration Iteration Release) 🌪️🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 发布类型 (Release Type): 🧪 Alpha v0.0.2 (Early Testing Iterative Update)
🎮 游戏版本 (Game Version): 1.16.5 & 1.18.2 & 1.19.2 & 1.20 & 1.20.1 & 1.20.4 & 1.21 & 1.21.1
💻 运行端 (Platform): Client‑Side Only (纯客户端)
📁 资源包体积 (File Size): 极限轻量化 (依旧零度性能损耗 ❄️📉)
📜 开源协议 (License): CC‑BY‑NC‑ND 4.0 ⚖️ (附带特批补丁例外条款 🛡️)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 【 版本核心概述 / Core Overview 】 📖
🎉🌟 重大迭代更新来袭！本次版本在保留 DawnAurora Smooth v0.0.1 全部原版布料、鞘翅、火把、微表情全套物理动画的基础之上，完成全新第一人称手臂物理系统的完整集成💥！
我们完全沿用原有CEM骨骼扩展方案，不篡改原有两份核心jem的任何原始代码，把外部独立的手臂物理逻辑无损嫁接合并进主体文件，解决旧独立物理文件加载失效的顽疾，给角色双手赋予更加鲜活、跟随运动响应的惯性动态！🔥👐
Welcome to the iterative update of DawnAurora Smooth! This build preserves ALL v0.0.1 original cloth, elytra, torch and micro‑expression animations, while integrating brand‑new first‑person arm‑physics system🚀.
⚠️ 开发者极客碎碎念 (Dev's Geek Note)：本次为Alpha迭代测试版本，手臂物理会在第三人称视角同步生效，可通过内置全局参数自由调节强弱。底层全部为追加式叠加逻辑，原有全部原版表现完全不受破坏，后续版本会持续打磨视角区分与手感曲线！🙇‍♂️✨
Arm‑physics also works in third‑person view in this alpha build, tune global variable for intensity adjustment. Original animations remain untouched, further polish will come in later updates! 🛠️
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✨ 【 迭代新增特性与功能变更 / New Features & Function Changes 】 ✨
💪 ▶️ 双层级弹簧手臂惯性物理系统 (Dual‑Layer Spring Arm Inertia Physics) 🌀
· 🛑 彻底修复外部独立物理文件加载失效问题 (Fix Broken Standalone Physics Asset)：旧版单独的手臂物理jem存在格式缺陷，游戏内静默失效无报错；现已把整套手臂物理全部迁移合并进主模型文件，删除损坏独立文件，功能稳定常驻不再凭空消失🚫
· 🔄 主轴大惯性摆动反馈 (Main‑Spring Large Inertia Swing)：疾跑奔跑、高空坠落落地、高速急停刹停的时候，双臂会生成贴合动作力度的惯性甩动，动作越激烈摆动幅度越强，静止后顺滑回归中立姿态🏃‍♂️
· ✨ 二级高频冲击余颤细节 (High‑Frequency Secondary Spring Tremble)：落地撞击、瞬间急停之后，手臂会产生短促细腻回弹震颤，补充肢体受冲击的微小动态细节，大幅度提升动作的真实质感💫
· 🧥 袖子关节同步跟随修复 (Sleeve Joint Sync Fix)：手臂触发物理偏转摆动时，袖子部件完整跟随右臂同步转动，彻底消除模型错位、穿插穿模的视觉瑕疵👕
· Arms respond to sprint, landing and hard stop with inertia swing & subtle impact tremble, sleeves perfectly follow arm movement! 😎
 
🎚️ ▶️ 全局手臂物理强度可控参数 (Global Arm‑Physics Intensity Controller) 🎛️
· 🎯 内置  var.fp_gain  全局控制变量：可自由在0‑1区间调节整套手臂物理的整体效果强度；参数设置为0时，所有附加手臂物理效果直接关闭，角色手臂100%还原 v0.0.1 原版全部表现，无需修改任何底层代码✅
· Full intensity tunable via  var.fp_gain , set value to 0 to revert back to vanilla arm behaviour of v0.0.1! ✨
 
🚫 ▶️ 摒弃旧版时间驱动虚假摆动逻辑 (Remove Old Time‑Driven Fake Swing Logic) 🚫
· 🧭 全部手臂摆动抖动完全依托角色真实位移运动数据进行触发，角色原地站定待机状态下，手臂不会产生无来由的自动乱晃，杜绝脱离实际动作的机械虚假摆动🧍
· 🛡️ 加入帧时间安全限位保护，面对游戏掉帧、帧率剧烈波动场景，限制手臂运动幅度，避免出现手臂乱飞、极端穿模的崩坏现象⚡
· Arm motions are fully driven by entity real movement data. No idle fake arm wobble, with frame‑time safety clamp to prevent extreme clipping on low FPS! 🛡️
 
🌊 ▶️ 兼容性更新说明 (Compatibility Update Note)
· ✅ Wavey Capes飘扬披风模组不再存在冲突！经过实机测试验证，本包手臂物理与Wavey Capes披风摆动逻辑可以同时启用并行工作，不会引发手臂异常疯狂抖动💞
· Wavey Capes is now fully compatible! Both cape motion and our new arm‑physics can run side‑by‑side without abnormal jitter! 🌊
 
💡 重要继承说明：v0.0.1全部已有功能完整保留
多轴弹簧折叠披风布料物理🌪️｜双重刚性空气动力学鞘翅🦅｜第一人称火把沉浸物理💡｜史诗级微表情眨眼系统👁️‍🗨️｜全量动作底层身体惯性 ⚙️，全部功能维持原有表现，没有任何删减改动！
 
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛠️ 【 严苛的前置需求与安装避坑指南 / Strict Requirements & Install Guide 】 🛠️
❗❗❗ 必须安装的前置依赖 (MUST INSTALL Dependencies)：
· ✅ Entity Model Features (EMF) 🦴 (骨骼与物理引擎的核心驱动！)
· ✅ Entity Texture Features (ETF) 🎨 (材质与贴图渲染的终极支撑！)
· 🚫 如果不装前置，资源包将毫无效果！ 🤖
💥 极度危险冲突警告与设置说明 (CRITICAL WARNING)：
· 🛑 如果你使用 EMF + ETF (极力推荐)：不需要去视频设置里开启“自定义实体模型”！EMF 自带底层渲染接管，模组装好、资源包启用即自动生效！✅
· 🚫 绝对不要与 OptiFine 同时安装！ 底层渲染逻辑冲突会导致游戏直接崩溃（Crash）！💥
· 🌅 如果你非要用 OptiFine (老方案/不推荐)：你才需要去游戏 视频设置 -> 质量 中，手动开启 "自定义实体模型 (Custom Entity Models)"，否则动作不生效！⚠️
· DO NOT install with OptiFine! EMF/ETF users do NOT need to manually enable "Custom Entity Models" in settings, it works automatically! 🛑
 
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🩺 【 终极排障与急救指南 (FAQ & Troubleshooting) 】 🩺
❓ Q：更新之后原版披风、鞘翅、火把、眨眼效果不见了？ 🤖
👉 A：确认资源包放置在资源包列表最顶端，旧版本文件需要完全删除，不要新旧版本文件混杂在一起！
❓ Q：第三人称看到手臂也在晃动，是不是BUG？ 👀
👉 A：属于当前Alpha版本已知特性，CEM无法区分游戏一/第三人称状态。你可以调高/调低  var.fp_gain  参数，或者直接置0关闭手臂物理，不影响其余全部布料物理功能。
❓ Q：手臂出现错位穿模？ 💢
👉 A：检查是否有其他玩家模型资源包覆盖本包jem文件，DawnAurora需要优先级置于资源包列表最高位。
❓ Q：我在服务器里能用吗？会崩服吗？ 🌐
👉 A：完全可以！本包依旧为纯客户端视觉资源包，绝对不增加服务器负担，也不会导致崩服。
 
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚖️ 【 开源协议与神圣法则 (含特批通道) / License & Sacred Law 】 ⚖️
📜 协议类型 (License Type): CC‑BY‑NC‑ND 4.0
为了维护纯粹的极客创作环境，本包严禁商业倒卖、洗稿套壳以及未经授权的大规模魔改发布 🛡️。但为了防止误伤热心社区，我们特别开启以下【善意补丁特批通道 (Special Patch Permission)】：
· ✅ 允许发布兼容补丁 (Compatibility Patches)：欢迎发布让 DawnAurora 与其他模组更好兼容的补丁包。
· ✅ 允许发布 Bug 修复补丁 (Bug Fix Patches)：如果你发现了代码错误并制作了修复补丁，非常欢迎你发布出来帮助大家！
· ✅ 允许发布辅助性扩展 (Add‑ons)：只要是不包含原版核心物理代码、旨在辅助本包运行的附加文件。
· ⚠️ 唯一要求 (The Only Rule)：所有补丁与扩展必须明确标注原作者 DawnAurora0221，必须免费发布，且不得替代/覆写本体的核心文件。只要是为了 DawnAurora 更好（For the good of DawnAurora），我们绝对欢迎！
Special Permission Granted: You are ALLOWED to publish compatibility patches, bug fix patches, and add‑ons for DawnAurora, as long as they are free, credit DawnAurora0221, and do not overwrite the core files of this project. Let's make it better together! 🐾💖
 
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 【 未来进化路线图 / Future Roadmap 】 🚀
· 🩹 Phase 1.5 (Next Up): 优化手臂物理手感曲线，尝试寻找视角区分实现方案，进一步打磨布料与手臂细节穿模问题🛠️
· 🧊 Phase 2: 3D 物理物品时代：基于 CEM 框架，手搓真正的立体护甲、灵动的动态 3D 乌龟壳，让装备也具有物理重量感！🐢🛡️
· 💻 Phase 3: 26.1.2+ 原生级底层模组：彻底抛弃 EMF 前置，直接利用官方无混淆代码进行 Mixin 渲染注入，带来真正的零前置体验！🔥🤖
 
💖 感谢您见证 DawnAurora 的迭代进化！让我们一起，把 Java 版的动作体验推向极致！ 🐾🚀
💖 Thank you for witnessing the evolution of DawnAurora! Let's push Java Edition animations to the absolute limit! 🐾🚀
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━