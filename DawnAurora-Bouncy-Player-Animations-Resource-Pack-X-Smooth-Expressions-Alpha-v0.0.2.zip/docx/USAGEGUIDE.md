━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛠️✨🚀🌪️ D A W N A U R O R A - U S A G E G U I D E 🌪️🚀✨🛠️
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎩🫡 【 极客终端操作手册 / Geek Terminal User Manual 】 🫡🎩
👋 Welcome, Explorer! 欢迎，探险家！ 🌍
恭喜你下载了 DawnAurora 灵动物理引擎！为了让你体验到 100% 纯手搓的极致物理布料与动作反馈，请务必仔细阅读并严格遵守本使用指南！📖✨
Congratulations on downloading DawnAurora! To experience the 100% hand-crafted physics, please read and follow this guide strictly! 🛡️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🛑❗ 【 第一步：前置依赖 (极度重要!) / Step 1: Dependencies (Critical!) 】 ❗🛑

如果你不装前置，本包将毫无效果，你会看到一个宛若植物人般僵硬的史蒂夫！ 🤖🥀
If you don't install the dependencies, the pack will NOT work. You will see a stiff Steve! 💥

✅ 必须安装的核心驱动 (MUST INSTALL)：

1. 🦴 Entity Model Features (EMF) —— 骨骼动画与物理引擎的终极核心！(The ultimate core for bones & physics!)
2. 🎨 Entity Texture Features (ETF) —— 材质与贴图渲染的底层支撑！(Underlying support for textures!)

🚫 绝对严禁安装的模组 (DO NOT INSTALL)：

· 💀 OptiFine (高清修复)：它是极其危险的“远古毒药”！EMF/ETF 与 OptiFine 的底层渲染逻辑完全冲突，同时安装会导致游戏直接崩溃（Crash）！💥
· DO NOT install with OptiFine! It will crash your game immediately! ☠️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🛠️🚀 【 第二步：安装步骤 / Step 2: Installation Steps 】 🚀🛠️

Step 1️⃣：下载压缩包 (Download the ZIP) 📦
👉 下载本项目的 .zip 文件。注意：千万不要解压它！千万不要！ 🚫
Download the .zip file. DO NOT UNZIP IT! 🚫

Step 2️⃣：精准拖入文件夹 (Drop into Folder) 📂
👉 打开你的游戏根目录（.minecraft），找到 resourcepacks 文件夹。把 .zip 文件直接拖进去！💨
Open your .minecraft folder, find resourcepacks, and drag the .zip file in! 💨

Step 3️⃣：游戏内启用与【置顶法则】 (Enable & Move to TOP) ⬆️🏆
👉 启动游戏，进入 选项 -> 资源包。找到 DawnAurora 并点击 启用。
👉 🔥 【核心法则】：请务必把 DawnAurora 置于资源包列表的最顶端！如果你的列表里有其他动作包（如 Fresh Moves），必须让 DawnAurora 覆盖它们，否则你的披风会被其他包覆盖导致疯狂乱飞！
🔥 CRITICAL: Make sure DawnAurora is at the VERY TOP of your resource pack list to override other animation packs! 🥇

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚙️🧠 【 第三步：视频设置终极防坑 (In-Game Settings) 】 🧠⚙️

🚨 针对 EMF + ETF 用户 (极客首选)：
👉 什么都不用开！ EMF 会完全自动接管底层渲染。只要模组放进了 mods 文件夹，资源包启用了，它就会自动生效！别去视频设置里瞎找了！✅
For EMF/ETF users: NO MANUAL SETTINGS NEEDED! It works automatically! 🪄

⚠️ 针对 OptiFine 用户 (极度不推荐)：
👉 如果你非要头铁用 OptiFine（本狗极其不推荐），你必须去 视频设置 -> 质量 里，把 "自定义实体模型 (Custom Entity Models)" 强行开到 开启 (ON)！否则动作绝对无效！🚫
OptiFine users: You MUST enable "Custom Entity Models" in Video Settings! ⚙️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🩺🛑 【 第四步：终极排障急救大百科 / Ultimate Troubleshooting 】 🛑🩺

❓ Q1：为什么我的披风疯狂穿模/糊到了脸上？ 🌪️
👉 A：请确保你使用的是最新的 Alpha 版本（包含倒退折叠与防穿模锁死逻辑）。如果依然飞脸，检查资源包排序！必须放在最顶端！ ⬆️

❓ Q2：为什么我的鞘翅在地面疯狂抽搐/乱抖？ 🦅
👉 A：这是被旧版本的动作包覆盖了。请把 DawnAurora 置顶。我们的鞘翅在地面拥有“刚性死锁”逻辑，绝对不抖！🗿

❓ Q3：为什么火把拿在手里没有摇晃的物理惯性？ 🔥
👉 A：第一人称火把物理只有在手持火把/灯笼且处于第一人称视角时才生效。如果你拿的是剑或者空手，是不会触发的哦！⚔️

❓ Q4：这个包能用在服务器或整合包里吗？ 🌐
👉 A：100% 可以！本包是纯粹的资源包（纯客户端），0 模组冲突，0 服务器负担。服主和整合包作者狂喜！🎉🖥️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💖 【 结语 / Conclusion 】 💖

感谢你选择 DawnAurora 灵动版！如果在游玩过程中发现了任何 Bug，或者有绝妙的点子，欢迎在 GitHub 或 Discord 提交反馈！🛡️
Thank you for choosing DawnAurora! If you find any bugs, please report them on GitHub or Discord! 🚀

祝你在这片灵动的物理宇宙中，游玩愉快！ / Have a great time in this agile physics universe! 🐾✨💖
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━