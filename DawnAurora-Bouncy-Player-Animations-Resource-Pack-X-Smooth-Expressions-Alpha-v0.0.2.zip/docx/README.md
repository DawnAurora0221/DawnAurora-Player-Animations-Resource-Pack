━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🔥 DawnAurora Player Animations 🔥✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

<p align="center">
  <img src="https://img.shields.io/badge/Version-v0.0.4--Alpha-orange?style=for-the-badge&logo=github" alt="Version">
  <img src="https://img.shields.io/badge/Game-1.20.1_%7C_1.20-green?style=for-the-badge&logo=minecraft" alt="Game Version">
  <img src="https://img.shields.io/badge/Size-460KB-blueviolet?style=for-the-badge" alt="Size">
  <img src="https://img.shields.io/badge/License-CC--BY--NC--SA--4.0-blue?style=for-the-badge&logo=creativecommons" alt="License">
</p>

<p align="center">
  <b>“拒绝臃肿，拒绝赞助墙。我们只做纯粹的物理引擎。”</b><br>
  <i>"No bloat, no paywalls. We only craft pure, free physics engines."</i>
</p>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📖 【 目录 / Table of Contents 】

1. [🌌 欢迎来到极光赛博宇宙 / Welcome to DawnAurora](#-欢迎来到极光赛博宇宙--welcome-to-dawnaurora)
2. [🌟 核心特性底层揭秘 / Core Features Deep Dive](#-核心特性底层揭秘--core-features-deep-dive)
3. [🛠️ 严苛的前置需求与安装避坑指南 / Strict Requirements & Install Guide](#%EF%B8%8F-严苛的前置需求与安装避坑指南--strict-requirements--install-guide)
4. [❓ 常见问题解答 (FAQ) / Frequently Asked Questions](#-常见问题解答-faq--frequently-asked-questions)
5. [☕ 开发者赛博修仙日记 / Developer's Cyber Cultivation Log](#-开发者赛博修仙日记--developers-cyber-cultivation-log)
6. [💸 赞助、开源与神圣法则 / Sponsorship, Open Source & Sacred Law](#-赞助开源与神圣法则--sponsorship-open-source--sacred-law)
7. [🚀 未来进化路线图 / Future Roadmap](#-未来进化路线图--future-roadmap)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🌌 【 欢迎来到极光赛博宇宙 / Welcome to DawnAurora 】

🎉🌟 欢迎来到 **DawnAurora (极光)** 的绝对起点！这是一个从零到一的奇迹。

在 Minecraft 的漫长岁月里，原版史蒂夫总是像一个没有灵魂的“机械木偶”，走路像滑冰，举手像木棍，眼神更是死气沉沉的“死鱼眼”。传统的动作包要么体积庞大、疯狂掉帧，要么为了恰饭把测试版锁在高昂的赞助墙后。

**因此，DawnAurora 诞生了。**

我们抛弃了所有臃肿的依赖和商业化的套路，利用 100% 纯手搓的 CEM（Custom Entity Models）底层代码，为你注入真实的 **物理惯性、重量感与生命**。这不仅仅是一个资源包，这是我们在代码深渊中创造的生命奇迹！

*Welcome to the absolute starting point of **DawnAurora**! In the long history of Minecraft, vanilla Steve always walks like he's ice-skating and stares with dead eyes. Traditional animation packs are either bloated and laggy, or lock their beta versions behind paywalls. Therefore, DawnAurora was born. We abandoned all bloated dependencies and used 100% hand-crafted CEM code to inject real physical inertia, weight, and life into your character. This is not just a resource pack; it's a miracle of life created in the abyss of code!*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🌟 【 核心特性底层揭秘 / Core Features Deep Dive 】

### 👁️‍🗨️ 1. Smooth_Expressions 微表情系统底层重构 (Micro-Expression System)
*   🔮 **黑科技降临 (Black Tech Descends)**：无需替换任何自定义皮肤文件！我们直接在底层 CEM 的头部骨骼（`Head` Bone）节点上，强行挂载了独立的眼皮动画层（`Eyelid Animation Layer`）。
*   😉 **灵魂开合逻辑 (Soul Blinking Logic)**：通过正弦波插值（`Sine Wave Interpolation`），让角色的眨眼不再生硬。无论是第一人称发呆，还是第三人称奔跑，那微小、顺滑、带有一丝萌感的眼皮开合，绝对能瞬间击穿你的防线！
*   🧬 **骨骼拓扑学重构**：为了挂载表情系统，我们重新计算了 Head 骨骼的 UV 映射与渲染矩阵，完美避开了 Z-fighting（深度冲突）。

### 🎀 2. 极致 Q 弹萌系物理惯性 (Ultra-Bouncy Physics Inertia)
*   🏃‍♂️ **非线性插值 (Non-linear Interpolation)**：基于 `limb_speed`（肢体速度）与 `ractionT` 变量的二次方计算。每一次起步、跳跃、急停，都带着极其轻快、Q 弹可爱的灵动感！
*   🛑 **急停弹簧阻尼 (Hard-Stop Spring Damping)**：当你松开方向键，身体会像弹簧一样产生微小的前后回弹。再也不是像被空气墙拍了一下！
*   🕊️ **滞空与坠落反馈 (Airtime & Falling Feedback)**：基于 `fall` 变量的重力加速度，当角色下坠时，四肢与披风会根据下坠速度产生拉伸与向上撕扯感。

### 🪶 3. 令人发指的极限轻量化 (Ultra-Lightweight Obsession)
*   📦 **460KB 的虚空极限 (The 460KB Void Limit)**：我们正在挑战 MC 资源包的物理极限。通过剔除所有无用顶点、压缩 JSON 空白字符，力求把整个物理引擎塞进 460KB 的次元口袋里！
*   💻 **绝对零度掉帧 (Zero FPS Drop)**：哪怕你用十年前的核显，哪怕整合包里塞了 500 个模组，加载这个包也是瞬间秒进，FPS 稳如泰山！❄️🎮

### 🎨 4. 纯正原版风与跨版本生态 (Authentic Vanilla & Cross-Version)
*   🍃 **不搞花里胡哨**：拒绝贴图堆砌，专注物理本身。完美保留 MC 原始像素美学。
*   🌍 **全量覆盖**：老版本（1.20/1.20.1）用 CEM 资源包硬扛，高版本（26.1.2+）将直接降维切入原生模组（Mixin 注入）！

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🛠️ 【 严苛的前置需求与安装避坑指南 / Strict Requirements & Install Guide 】

### ❗ 必须安装的前置模组 (MUST INSTALL)：
如果不装前置，资源包将**毫无效果**，你看到的依然是原版的僵尸动作！
*   ✅ **Entity Model Features (EMF)**
*   ✅ **Entity Texture Features (ETF)**

### 🚨 极度危险冲突警告 (CRITICAL WARNING)：
1.  **EMF/ETF 与 OptiFine（高清修复）是水火不容的死敌！** 💥 绝对、绝对、绝对不要把它们同时安装在游戏里，否则底层渲染矩阵冲突会导致游戏直接崩溃（Crash）！
2.  如果你需要光影，请务必使用 **Iris + EMF + ETF** 的组合！
3.  **最重要的一步**：请务必在游戏设置（视频设置）中，找到并开启 **"自定义实体模型 (Custom Entity Models)"**！否则一切白搭！✅

### 📥 安装步骤：
1. 下载资源包 `.zip` 文件。
2. 把它拖入 `.minecraft/resourcepacks` 文件夹。
3. 启动游戏，在资源包界面启用它。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ❓ 【 常见问题解答 (FAQ) / Frequently Asked Questions 】

*   **Q: 为什么我的游戏崩溃了？**
    *   A: 99% 的概率是因为你同时装了 OptiFine 和 EMF/ETF。请删掉 OptiFine！
*   **Q: 为什么史蒂夫的手臂在某种状态下会骨折/抬不起来？**
    *   A: 这是已知的 Alpha 阶段渲染 Bug（矩阵串线与近平面裁剪问题），本作者正在修仙爆肝，下个版本必定超度它！
*   **Q: 这个包能用在服务器里吗？**
    *   A: 完全可以！它是纯客户端视觉资源包，绝对不增加服务器负担。
*   **Q: 为什么体积这么小（460KB）？是不是偷工减料？**
    *   A: 绝对不是！体积小是因为底层代码极致精简，没有塞入任何废料。这恰恰是极致性能优化的证明！

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## ☕ 【 开发者赛博修仙日记 / Developer's Cyber Cultivation Log 】

*   🗓️ **Day 1**：打开 IDEA，看着原版庞大的代码矩阵，发誓要手搓物理引擎。精神状态：极度自信。😎
*   🗓️ **Day 2**：火把的渲染坐标死活对不上，Z-fighting 让我崩溃。浓缩咖啡*3。🤬
*   🗓️ **Day 3**：为了让 `Smooth_Expressions` 眨眼动画不破坏第一人称手臂，再次在四元数（Quaternions）的汪洋大海里疯狂呛水。🌊☠️
*   🗓️ **Day 4 (05:30 AM)**：头发 -9999，键盘差点被砸烂。但在进游戏看到史蒂夫顺滑对自己眨眼的那一刻，一切都值了！😭💖
*   🗓️ **Day 5**：试图把文件压缩到 460KB，删掉空格后发现游戏崩溃，无奈加回一半。红牛空罐*2。💀
*   🗓️ **现在**：为了飞行状态的 Bug 再次掉发，但看着下载量慢慢上升，我感受到了纯粹的热爱。🔥

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 💸 【 赞助、开源与神圣法则 / Sponsorship, Open Source & Sacred Law 】

### 🛡️ 永不商业化 (Never Commercialize)
DawnAurora 的所有尝鲜版、测试版与正式版，将**永远第一时间向所有人免费开放**。我们极其唾弃某些项目（如 FA 等）把核心功能或测试版锁在 Patreon/爱发电 赞助墙后的“赛博特权”行为。

### ❤️ 自愿赞助 (Voluntary Sponsorship)
如果您觉得这个 460KB 的物理引擎为您带来了欢乐，欢迎通过 GitHub Sponsors 或爱发电请作者喝一杯咖啡。
**⚠️ 但请注意：赞助是纯粹的鼓励，不附带任何代码定制或特权要求。赞助不是贿赂，我们只为热爱写代码！**

### 📜 开源协议 (License) - `CC-BY-NC-SA 4.0`
本项目严格采用 **[CC-BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/)** 协议。
*   **BY (署名)**：必须明确标注原作者为 `DawnAurora0221`。抹除原作者身份直接侵权。
*   **NC (非商业性)**：**绝对严禁**将本资源包或其衍生代码用于任何形式的商业倒卖、付费服务器盈利、或整合包收费售卖。
*   **SA (相同方式共享)**：任何基于本项目的修改、二创或衍生作品，**必须**继续使用 `CC-BY-NC-SA 4.0` 协议开源发布！
*   🚫 **严禁套壳换协议 (No Shell-Cloning)**：绝对禁止将本项目的代码/模型直接扒走，改个名字后标上 `ARR`（保留所有权利）或闭源发布！一旦发现，全社区曝光追究！⚔️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🚀 【 未来进化路线图 / Future Roadmap 】

*   🩹 **Phase 1.5 / v0.0.5 (Next Up)**：
    *   彻底修复第一人称火把/物品抬不起手的 Bug。
    *   引入 `if(var.flying, 0, ...)` 排雷锁，修复飞行状态下惯性导致的鬼畜拉伸。
    *   继续挑战 460KB 的体积极限！
*   🧊 **Phase 2：3D 物理物品时代**：
    *   基于 CEM 框架的立体护甲、动态乌龟壳，全部安排上！让装备也具有物理重量感！
*   💻 **Phase 3：26.1.2+ 原生级底层模组**：
    *   彻底抛弃 EMF 前置！直接利用官方无混淆代码进行 Mixin 渲染注入，带来真正的零前置、最高性能体验！

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

<p align="center">
  <b>Created with 🩸, 💻, and ☕ by DawnAurora0221.</b><br>
  <i>"Let's make Java Edition animations great again!"</i> 🐾🚀
</p>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━