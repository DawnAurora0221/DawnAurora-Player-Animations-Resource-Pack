━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌅✨🚀🌪️ D A W N A U R O R A - C R E D I T S & L I C E N S E 🌪️🚀✨🌅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👑 【 赛博创世神 · 极客殿堂 / The Cyber Creator's Hall 】 👑
欢迎来到 DawnAurora 的绝对核心！这不是一个普通的资源包，这是一场由代码、算力与纯粹热爱交织而成的物理革命！💥
Welcome to the absolute core of DawnAurora! This is a physics revolution woven from code, computing power, and pure passion! 🌍

🛠️🦾 核心开发团队 (Core Development Team) 🦾🛠️

🔥 创始人兼底层物理引擎架构师 (Founder & Physicist) 👑
👤 DawnAurora0221 🧠

· 🏆 职位 (Role)：Owner / Animator / Physicist (所有者 / 动画师 / 物理学家)
· 💻 核心贡献 (Core Contributions)：
  · 100% 纯手搓底层 CEM 骨骼矩阵与多轴弹簧阻尼算法！📐
  · 重写了第一人称火把惯性物理、披风折叠布料引擎与鞘翅双重空气动力学！🔥
  · 实现了无需替换皮肤的 Smooth_Expressions 动态微表情骨骼挂载系统！👁️
  · Hand-crafted 100% pure CEM skeleton matrices, spring damping algorithms, torch physics, cape folding, and elytra aerodynamics! 🚀

🧊 次世代 3D 视觉与建模大师 (Lead 3D Modeler) ⚔️
👤 AuroraForge0221 🎨

· 🏆 职位 (Role)：Member & Modeler (核心成员 / 3D 资产锻造师)
· 📦 核心贡献 (Core Contributions)：
  · 正在疯狂爆肝研发次世代 3D 物理物品（灵动的立体乌龟壳、动态厚重护甲等）！🐢🛡️
  · 负责所有高阶材质与 3D 模型的结构重塑与视觉风格统一！✨
  · Currently developing next-gen 3D physics items (dynamic turtle shells, heavy armors) and reconstructing 3D models! 🎨

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚖️🛡️ 【 神圣开源法则 / The Sacred License 】 🛡️⚖️

📜 协议类型 (License Type): CC-BY-NC-ND 4.0 (署名—非商业性使用—禁止演绎)

🚨 严禁行为 (Strictly Prohibited)：

· 🚫 商业倒卖：绝对禁止将本包或其任何衍生内容用于淘宝/闲鱼倒卖、付费服务器盈利、或付费整合包售卖！(NO commercial resale!)
· 🚫 洗稿套壳：绝对禁止扒取本包的物理代码、模型、贴图，改名换姓后重新发布！(NO shell-cloning!)
· 🚫 演绎修改：严禁任何未经授权的魔改或修改后发布！你可以自己用，但不能二次发布！(NO derivatives!)

✅ 善意补丁特批通道 (Special Patch Permission)：
为了防止误伤真正热爱社区的大佬，我们特别开放以下特批权限：

· 🤝 允许发布兼容补丁 (Compatibility Patches)：如与其他动作模组（Parcool等）的联动补丁。
· 🔧 允许发布 Bug 修复补丁 (Bug Fix Patches)：欢迎帮我们修复 Bug 并免费发布！
· 🧩 允许发布辅助扩展 (Add-ons)：不覆盖本体核心代码的辅助文件。
· ⚠️ 唯一要求 (The Only Rule)：必须明确标注原作者 DawnAurora0221，必须完全免费，且不得覆写本体核心文件！
· Special Permission: You are allowed to publish free compatibility/bug-fix patches, provided you credit DawnAurora0221 and do not overwrite the core files! 💖

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💖 【 特别致谢 / Special Thanks 】 💖

· 🌟 EMF & ETF 开发团队 (Entity Model Features & Entity Texture Features)：感谢你们提供了如此强大的底层渲染框架，让纯资源包的极致物理得以实现！
· ⚙️ Minecraft 极客社区 (The MC Geek Community)：感谢所有提供 Bug 反馈、测试与支持纯原创的玩家们！
· 👑 每一位不屑于套壳洗稿，坚持手搓代码的原创开发者 (To all original devs who refuse to shell-clone)：Respect！🫡

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💬 【 开发者的极客宣言 / The Geek's Manifesto 】 💬

"真正的物理不应该靠付费墙来兜售，也不应该靠偷窃别人的代码来拼凑。"
"Real physics should not be sold behind paywalls, nor pieced together by stealing others' code."

We hand-craft every frame, every matrix, every mathematical calculation. 🧮🔥
我们手搓每一帧、每一个矩阵、每一次数学计算。

DawnAurora will ALWAYS be free to play. NO PAYWALLS. 🛡️
DawnAurora 将永远免费，没有付费墙。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ Created with 🩸, 💻, and ☕ by DawnAurora0221 & AuroraForge0221. ✨
💖 Thank you for supporting 100% original content! / 感谢您支持 100% 纯原创内容！ 💖
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━