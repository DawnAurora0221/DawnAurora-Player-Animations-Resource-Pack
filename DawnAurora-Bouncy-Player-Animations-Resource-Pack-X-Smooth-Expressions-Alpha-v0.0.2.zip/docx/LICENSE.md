
---

Creative Commons Legal Code

Attribution-NonCommercial-NoDerivatives 4.0 International

署名—非商业性使用—禁止演绎 4.0 协议国际版

---

About the license and Creative Commons / 关于本协议与知识共享组织

Creative Commons Corporation (“Creative Commons”) is not a law firm and does not provide legal services or legal advice. Distribution of Creative Commons public licenses does not create a lawyer-client or other relationship. Creative Commons makes its licenses and related information available on an “as-is” basis. Creative Commons gives no warranties regarding its licenses, any material licensed under their terms and conditions, or any related information. Creative Commons disclaims all liability for damages resulting from their use to the fullest extent possible.

知识共享组织（“Creative Commons”，“知识共享”）不是一家律师事务所，也不对外提供法律服务或建议。提供知识共享公共许可协议（Creative Commons Public License，以下缩写为CCPL）并不导致“律师—当事人”关系或其他法律关系的建立。知识共享按其现状提供协议文本和相关信息。知识共享对于其许可协议，或通过该协议提供的作品或相关信息不提供任何担保，在最大可能程度内，也不对因使用其协议或通过该协议提供的作品或信息而造成的损失承担损害赔偿责任。

---

Using Creative Commons Public Licenses / 知识共享公共许可协议的使用

Creative Commons public licenses provide a standard set of terms and conditions that creators and other rights holders may use to share original works of authorship and other material subject to copyright and certain other rights specified in the public license below. The following considerations are for informational purposes only, are not exhaustive, and do not form part of our licenses.

知识共享公共许可协议提供一套标准化的条款供作者或其他权利人使用，以便他们分享其原创作品和其他受著作权及以下公共许可协议中提及的其他特定权利保护的作品。以下考虑因素仅供参考，并未列举穷尽，也不属于本公共许可协议文本的一部分。

Considerations for licensors: Our public licenses are intended for use by those authorized to give the public permission to use material in ways otherwise restricted by copyright and certain other rights. Our licenses are irrevocable. Licensors should read and understand the terms and conditions of the license they choose before applying it. Licensors should also secure all rights necessary before applying our licenses so that the public can reuse the material as expected. Licensors should clearly mark any material not subject to the license. This includes other CC-licensed material, or material used under an exception or limitation to copyright.

许可人应当考虑的因素： 知识共享公共许可协议是供那些有权许可公众以著作权或其他特定权利所保护的方式使用其作品的权利人使用的。知识共享协议不可撤销。因此，在采用协议前，许可人应当阅读并理解其所选择的协议条款。许可人亦应确保其享有所授予公众的权利，以便公众能够顺利的使用授权作品。许可人应当清楚地注明协议所不适用的作品，包括其他采用知识共享协议授权的作品，或基于著作权的例外或限制而使用的作品。

Considerations for the public: By using one of our public licenses, a licensor grants the public permission to use the licensed material under specified terms and conditions. If the licensor’s permission is not necessary for any reason–for example, because of any applicable exception or limitation to copyright–then that use is not regulated by the license. Our licenses grant only permissions under copyright and certain other rights that a licensor has authority to grant. Use of the licensed material may still be restricted for other reasons, including because others have copyright or other rights in the material. A licensor may make special requests, such as asking that all changes be marked or described. Although not required by our licenses, you are encouraged to respect those requests where reasonable.

公众应当考虑的因素： 许可人通过使用知识共享协议，授权公众依据特定的条款和条件使用授权作品。如果因为任何原因不需要授权即可使用该作品——例如基于著作权的例外或限制——那么该使用并不受本协议约束。许可人通过知识共享协议只能授予基于著作权或其他特定权利有权授予的许可。使用授权作品可能还受到其他情形的限制，包括第三方对该作品所享有的著作权或其他权利。许可人可能做出其他特别要求，比如要求使用者标注或说明对作品的所有更改。即使本协议没有要求，知识共享仍然鼓励您遵守许可人的合理要求。

---

Attribution-NonCommercial-NoDerivatives 4.0 International / 署名—非商业性使用—禁止演绎 4.0 协议国际版

By exercising the Licensed Rights (defined below), You accept and agree to be bound by the terms and conditions of this Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International Public License ("Public License"). To the extent this Public License may be interpreted as a contract, You are granted the Licensed Rights in consideration of Your acceptance of these terms and conditions, and the Licensor grants You such rights in consideration of benefits the Licensor receives from making the Licensed Material available under these terms and conditions.

通过行使本协议所授予的权利（定义如下），您接受并同意受到知识共享署名—非商业性使用—禁止演绎4.0国际公共许可协议（以下简称“本公共许可协议”）的约束。从合同解释的角度来看，您获得授权的对价是接受本协议的条款，许可人授予您这些权利的对价是可以通过采用本协议条款发布授权作品而获得利益。

---

Section 1 – Definitions / 第一条 定义

a. Adapted Material means material subject to Copyright and Similar Rights that is derived from or based upon the Licensed Material and in which the Licensed Material is translated, altered, arranged, transformed, or otherwise modified in a manner requiring permission under the Copyright and Similar Rights held by the Licensor. For purposes of this Public License, where the Licensed Material is a musical work, performance, or sound recording, Adapted Material is always produced where the Licensed Material is synched in timed relation with a moving image.

演绎作品：指受到著作权与类似权利保护的，基于授权作品而创作的作品，例如对授权作品的翻译、改编、编排、改写或其他依据著作权与类似权利需要获得所有人许可的修改。为本公共许可协议之目的，当授权作品为音乐作品、表演或录音时，将其依时间序列关系与动态影像配合一致而形成的作品，视为演绎作品。

b. Effective Technological Measures means those measures that, in the absence of proper authority, may not be circumvented under laws fulfilling obligations under Article 11 of the WIPO Copyright Treaty adopted on December 20, 1996, and/or similar international agreements.

有效的技术措施：指根据各司法管辖区遵循《世界知识产权组织版权条约》（1996年12月20日通过）第十一条或类似国际协定项下的义务所制定的法律，在没有适当的授权的情况下，禁止使用者规避的技术措施。

c. Exceptions and Limitations means fair use, fair dealing, and/or any other exception or limitation to Copyright and Similar Rights that applies to Your use of the Licensed Material.

例外与限制：指合理使用和/或其他适用于您对授权作品的使用的著作权与类似权利的例外或限制。

d. Licensed Material means the artistic or literary work, database, or other material to which the Licensor applied this Public License.

授权作品：指许可人通过本公共许可协议授权的文学、艺术作品，数据库或其他作品。

e. Licensed Rights means the rights granted to You subject to the terms and conditions of this Public License, which are limited to all Copyright and Similar Rights that apply to Your use of the Licensed Material and that the Licensor has authority to license.

协议所授予的权利：指依据本公共许可协议的条款和条件所授予您的各项权利，限于适用于您对授权作品的使用且许可人有权许可的著作权与类似权利。

f. Licensor means the individual(s) or entity(ies) granting rights under this Public License.

许可人：指通过本公共许可协议进行授权的个人或组织。

g. NonCommercial means not primarily intended for or directed towards commercial advantage or monetary compensation. For purposes of this Public License, the exchange of the Licensed Material for other material subject to Copyright and Similar Rights by digital file-sharing or similar means is NonCommercial provided there is no payment of monetary compensation in connection with the exchange.

非商业性使用：指该使用的主要意图或者指向并非获取商业优势或金钱报酬。为本公共许可协议之目的，以数字文件共享或类似方式，用授权作品交换其他受到著作权与类似权利保护的作品是非商业性使用，只要该交换不涉及金钱报酬的支付。

h. Sui Generis Database Rights means rights other than copyright resulting from Directive 96/9/EC of the European Parliament and of the Council of 11 March 1996 on the legal protection of databases, as amended and/or succeeded, as well as other essentially equivalent rights anywhere in the world.

数据库特别权利：指除了著作权之外，衍生于1996年3月11日通过的《欧洲议会与欧盟理事会关于数据库法律保护的指令》及其修改或后续版本的权利，或其他国家或地区本质上与之等同的权利。

i. You means the individual or entity exercising the Licensed Rights under this Public License. Your has a corresponding meaning.

您：指依据本公共许可协议行使其所获得授予之权利的个人或机构。“您的”有相应的含义。

---

Section 2 – Scope / 第二条 授权范围

a. License grant.

1. Subject to the terms and conditions of this Public License, the Licensor hereby grants You a worldwide, royalty-free, non-sublicensable, non-exclusive, irrevocable license to exercise the Licensed Rights in the Licensed Material to:
   A. reproduce and Share the Licensed Material, in whole or in part, for NonCommercial purposes only; and
   B. produce and reproduce, but not Share, Adapted Material for NonCommercial purposes only.

授权：根据本公共许可协议的条款，许可人授予您在全球范围内，免费的、不可再许可、非独占、不可撤销的许可，以对授权作品行使以下“协议所授予的权利”：

A. 复制和分享授权作品的全部或部分，仅限于非商业性使用；以及

B. 为非商业目的创作、复制演绎作品，但不得分享该演绎作品。

b. Exceptions and Limitations. For the avoidance of doubt, where Exceptions and Limitations apply to Your use, this Public License does not apply, and You do not need to comply with its terms and conditions.

例外和限制：为避免疑义，若著作权的例外和限制适用于您对授权作品的使用，本公共许可协议将不适用，您也无须遵守本公共许可协议之条款。

c. Term. The term of this Public License is specified in Section 6(a).

期限：本公共许可协议的期限规定于第六条a款。

d. Media and formats; technical modifications allowed. The Licensor authorizes You to exercise the Licensed Rights in all media and formats whether now known or hereafter created, and to make technical modifications necessary to do so. The Licensor waives and/or agrees not to assert any right or authority to forbid You from making technical modifications necessary to exercise the Licensed Rights, including technical modifications necessary to circumvent Effective Technological Measures. For purposes of this Public License, simply making modifications authorized by this Section 2(a)(4) never produces Adapted Material.

媒介和形式；允许的技术修改：许可人授权您在任何媒介以任何形式（不论目前已知的或未来出现的）行使本协议授予的权利，并为之进行必要的技术修改。许可人放弃和/或同意不主张任何权利以阻止您为了行使协议项下权利进行必要的技术修改，包括为规避有效技术措施所必须的技术修改。为了本公共许可协议之目的，基于本协议第二条a款第(4)项进行的技术修改不构成演绎作品。

e. Downstream recipients.

1. Offer from the Licensor – Licensed Material. Every recipient of the Licensed Material automatically receives an offer from the Licensor to exercise the Licensed Rights under the terms and conditions of this Public License.
2. No downstream restrictions. You may not offer or impose any additional or different terms or conditions on, or apply any Effective Technological Measures to, the Licensed Material if doing so restricts exercise of the Licensed Rights by any recipient of the Licensed Material.

后续接受者：

来自许可人的要约——授权作品：本授权作品的每一个后续接受者都自动取得许可人的要约，以按照本公共许可协议的条款行使协议授予的权利。

禁止下游限制：若会限制授权作品后续接受者行使本协议所授予的权利，则您不得对授权作品提出或增加任何额外的或不同的条款，或使用任何有效技术措施。

f. No endorsement. Nothing in this Public License constitutes or may be construed as permission to assert or imply that You are, or that Your use of the Licensed Material is, connected with, or sponsored, endorsed, or granted official status by, the Licensor or others designated to receive attribution as provided in Section 3(a)(1)(A)(i).

并非背书：本公共许可协议不构成、或不得被解释为允许您声明或主张：您或您对授权作品的使用与许可人（或第三条a款第(1)项(A)目(i)所规定要求提供署名的权利人）相关联，或得到其赞助、同意或被授予正式地位。

g. Other rights.

1. Moral rights, such as the right of integrity, are not licensed under this Public License, nor are publicity, privacy, and/or other similar personality rights; however, to the extent possible, the Licensor waives and/or agrees not to assert any such rights held by the Licensor to the limited extent necessary to allow You to exercise the Licensed Rights, but not otherwise.
2. Patent and trademark rights are not licensed under this Public License.
3. To the extent possible, the Licensor waives any right to collect royalties from You for the exercise of the Licensed Rights, whether directly or through a collecting society under any voluntary or waivable statutory or compulsory licensing scheme. In all other cases the Licensor expressly reserves any right to collect such royalties, including when the Licensed Material is used other than for NonCommercial purposes.

其他权利：

依据本公共许可协议，著作人身权，例如保护作品完整权、形象权、隐私权或其他类似的人格权利，不在许可范围内。但是，在条件允许的情况下，许可人可以在必要范围内放弃和/或同意不主张其权利，以便您行使本协议所授予的权利。

本公共许可协议不适用于任何专利权或商标权许可。

在自愿的或可放弃的法定或强制许可机制下，许可人在最大可能范围内放弃对您因行使本协议所授予的权利而产生的使用费的权利，不论是直接收取或通过集体管理组织收取。在其他任何情况下（包括授权作品被商业性使用的情形），许可人明确保留收取使用费的任何权利。

---

Section 3 – License Conditions / 第三条 授权条件

Your exercise of the Licensed Rights is expressly made subject to the following conditions.

您行使被许可的权利明确受以下条件限制：

a. Attribution.

If You Share the Licensed Material, You must:

1. retain the following if it is supplied by the Licensor with the Licensed Material:
   A. identification of the creator(s) of the Licensed Material and any others designated to receive attribution, in any reasonable manner requested by the Licensor (including by pseudonym if designated);
   B. a copyright notice;
   C. a notice that refers to this Public License;
   D. a notice that refers to the disclaimer of warranties;
   E. a URI or hyperlink to the Licensed Material to the extent reasonably practicable;
2. indicate if You modified the Licensed Material and retain an indication of any previous modifications; and
3. indicate the Licensed Material is licensed under this Public License, and include the text of, or the URI or hyperlink to, this Public License.

For the avoidance of doubt, You do not have permission under this Public License to Share Adapted Material.

署名：

若您分享本授权作品，您必须：

保留如下标识（如果许可人提供授权作品的同时提供如下标识）：

A. 以许可人要求的任何合理方式，标识本授权作品创作者和其他被指定署名的人的身份（包括指定的笔名）；

B. 著作权声明；

C. 有关本公共许可协议的声明；

D. 有关免责的声明；

E. 在合理可行情况下，本授权作品的网址(URI)或超链接；

表明您是否修改本授权作品及保留任何先前修改的标记；及

表明授权作品依据本公共许可协议授权，并提供本公共许可协议全文，或者本公共许可协议的网址(URI)或超链接。

为避免疑义，依据本公共许可协议，您没有被授予分享演绎作品的许可。

b. You may satisfy the conditions in Section 3(a)(1) in any reasonable manner based on the medium, means, and context in which You Share the Licensed Material. For example, it may be reasonable to satisfy the conditions by providing a URI or hyperlink to a resource that includes the required information.

依据您分享本授权作品的媒介、方法及情況，您可以采用任何合理方式满足第三条a款第(1)项的条件。例如，提供包含所要求信息来源的网址(URI)或超链接可算是合理地满足此处的条件。

c. If requested by the Licensor, You must remove any of the information required by Section 3(a)(1)(A) to the extent reasonably practicable.

如果许可人要求，您必须在合理可行的范围内移除第三条a款第(1)项(A)目所要求的任何信息。

---

Section 4 – Sui Generis Database Rights / 第四条 数据库特别权利

Where the Licensed Rights include Sui Generis Database Rights that apply to Your use of the Licensed Material:

当协议所授予的权利包含数据库特别权利，而该数据库特别权利适用于您对授权作品的使用时：

a. for the avoidance of doubt, Section 2(a)(1) grants You the right to extract, reuse, reproduce, and Share all or a substantial portion of the contents of the database for NonCommercial purposes only and provided You do not Share Adapted Material;

为避免疑义，第二条a款第(1)项授权您，摘录、再利用、复制和分享全部或绝大部分数据库资料，但仅限于非商业性目的且不得分享演绎作品；

b. if You include all or a substantial portion of the database contents in a database in which You have Sui Generis Database Rights, then the database in which You have Sui Generis Database Rights (but not its individual contents) is Adapted Material; and

如果您将数据库资料的全部或绝大部分纳入您享有数据库特别权利的另一数据库，则您享有数据库特别权利的该数据库（而非其中的单个内容）视为演绎作品；

c. You must comply with the conditions in Section 3(a) if You Share all or a substantial portion of the contents of the database.

如果您分享全部或大部分该数据库的资料，您必须遵守第三条a款规定的条件。

For the avoidance of doubt, this Section 4 supplements and does not replace Your obligations under this Public License where the Licensed Rights include other Copyright and Similar Rights.

为避免疑义，当协议所授予的权利包含其他著作权与类似权利时，第四条补充且不取代本公共许可协议所规定的您的义务。

---

Section 5 – Disclaimer of Warranties and Limitation of Liability / 第五条 免责声明及责任限制条款

a. Unless otherwise separately undertaken by the Licensor, to the extent possible, the Licensor offers the Licensed Material as-is and as-available, and makes no representations or warranties of any kind concerning the Licensed Material, whether express, implied, statutory, or other. This includes, without limitation, warranties of title, merchantability, fitness for a particular purpose, non-infringement, absence of latent or other defects, accuracy, or the presence or absence of errors, whether or not known or discoverable. Where disclaimers of warranties are not allowed in full or in part, this disclaimer may not apply to You.

除非许可人另有保证，否则在最大可能范围内，许可人按其现状和现有之基础提供授权作品，且没有就授权作品做出任何形式的陈述或保证：无论明示、默示、法定或其他形式，包括但不限于任何有关本授权作品的权属保证、可交易性、适于特定目的、未侵害他人权利、没有潜在或其他瑕疵、精确性或是否有错误，不管是否已知或可发现。当免责声明全部或部分不被允许时，此免责声明可能不适用于您。

b. To the extent possible, in no event will the Licensor be liable to You on any legal theory (including, without limitation, negligence) or otherwise for any direct, special, indirect, incidental, consequential, punitive, exemplary, or other losses, costs, expenses, or damages arising out of this Public License or use of the Licensed Material, even if the Licensor has been advised of the possibility of such losses, costs, expenses, or damages. Where a limitation of liability is not allowed in full or in part, this limitation may not apply to You.

在最大可能范围内，对于任何因本公共许可协议或使用授权作品引起的直接的、特殊的、间接的、附随的、连带的、惩罚性的、警告性的，或其他的损失、成本、费用或损害，许可人不对您负任何法律上或其他的责任（包括但不限于过失责任）。当责任限制部分或全部不被允许时，该限制不适用于您。

c. The disclaimer of warranties and limitation of liability provided above shall be interpreted in a manner that, to the extent possible, most closely approximates an absolute disclaimer and waiver of all liability.

前述免责及责任限制声明，应尽可能以最接近于完全排除全部责任的方式解释。

---

Section 6 – Term and Termination / 第六条 期限与终止

a. This Public License applies for the term of the Copyright and Similar Rights licensed here. However, if You fail to comply with this Public License, then Your rights under this Public License terminate automatically.

本公共许可协议在著作权与类似权利存续期间内有效。然而，如果您没有遵守此公共许可协议，则您依据此公共许可协议享有的权利自动终止。

b. Where Your right to use the Licensed Material has terminated under Section 6(a), it reinstates:

1. automatically as of the date the violation is cured, provided it is cured within 30 days of Your discovery of the violation; or
2. upon express reinstatement by the Licensor.

当您使用本授权作品的权利根据第六条a款终止时，您的权利在下述情况下恢复：自违反协议的行为纠正之日起自动恢复，但须在您发现违反情形后30日内纠正；或根据许可人明示恢复权利的意思表达。

For the avoidance of doubt, this Section 6(b) does not affect any right the Licensor may have to seek remedies for Your violations of this Public License.

为避免疑义，本公共许可协议第六条b款不影响许可人就您违反本公共许可协议的行为寻求法律救济。

c. For the avoidance of doubt, the Licensor may also offer the Licensed Material under separate terms or conditions or stop distributing the Licensed Material at any time; however, doing so will not terminate this Public License.

为避免疑义，许可人也可在任何时间，以另外的条款或条件提供本授权作品，或者停止传播本授权作品；然而，许可人此种行为不会终止本公共许可协议。

d. Sections 1, 5, 6, 7, and 8 survive termination of this Public License.

本协议第一条、第五条、第六条、第七条及第八条，不因本公共许可协议终止而失效。

---

Section 7 – Other Terms and Conditions / 第七条 其他条款和条件

a. The Licensor shall not be bound by any additional or different terms or conditions communicated by You unless expressly agreed.

除非明示同意，否则许可人不受您表达的任何附加或不同条款或条件约束。

b. Any arrangements, understandings, or agreements regarding the Licensed Material not stated herein are separate from and independent of the terms and conditions of this Public License.

本公共许可协议未提及的关于授权作品之任何安排、共识或协议，不属于且独立于本公共许可协议的条款及条件。

---

Section 8 – Interpretation / 第八条 解释

a. For the avoidance of doubt, this Public License does not, and shall not be interpreted to, reduce, limit, restrict, or impose conditions on any use of the Licensed Material that could lawfully be made without permission under this Public License.

为避免疑义，本许可协议不会也不应被解释为减少、限制、约束或施加条件于无需本公共许可协议授权即可依法行使的对授权作品的任何使用。

b. To the extent possible, if any provision of this Public License is deemed unenforceable, it shall be automatically reformed to the minimum extent necessary to make it enforceable. If the provision cannot be reformed, it shall be severed from this Public License without affecting the enforceability of the remaining terms and conditions.

在最大可能范围内，如果本公共许可协议的任何条款被视为无法执行，该条款在必要的最小限度内，自动调整至可以执行。如果该条款不能被调整，其应自本公共许可协议中排除适用，不影响其余条款的效力。

c. No term or condition of this Public License will be waived and no failure to comply consented to unless expressly agreed to by the Licensor.

除许可人明示同意，本公共许可协议的任何条款或条件均不得放弃。

d. Nothing in this Public License constitutes or may be interpreted as a limitation upon, or waiver of, any privileges and immunities that apply to the Licensor or You, including from the legal processes of any jurisdiction or authority.

本公共许可协议条款不构成、也不得被解释为限制或者放弃适用于许可人或您的特权或豁免，包括豁免于任何司法管辖区或行政机构的法律程序。

---

About Creative Commons / 关于知识共享组织

Creative Commons is not a party to its public licenses. Notwithstanding, Creative Commons may elect to apply one of its public licenses to material it publishes and in those instances will be considered the “Licensor.” The text of the Creative Commons public licenses is dedicated to the public domain under the CC0 Public Domain Dedication. Except for the limited purpose of indicating that material is shared under a Creative Commons public license or as otherwise permitted by the Creative Commons policies published at creativecommons.org/policies, Creative Commons does not authorize the use of the trademark “Creative Commons” or any other trademark or logo of Creative Commons without its prior written consent including, without limitation, in connection with any unauthorized modifications to any of its public licenses or any other arrangements, understandings, or agreements concerning use of licensed material. For the avoidance of doubt, this paragraph does not form part of the public licenses.

知识共享组织不是其公共许可协议的一方。尽管如此，知识共享组织可以选择其中一种公共许可协议适用于其发表的作品，在此种情况下被视为许可人。知识共享公共许可协议的文本属于公共领域，适用CC0公共许可协议。除用于向公众表明本作品是依照知识共享公共许可协议授权，或发布于creativecommons.org/policies的知识共享组织政策另有规定允许以外，如未经知识共享组织事先书面同意，任何一方均不得使用“知识共享”商标和其他相关商标及标识。包括但不限于，将该商标或标识用于对知识共享公共许可协议做出的未经同意的修改，或与授权作品使用有关的其他安排、共识或协议。为避免疑义，本段关于商标的限制性规定不构成公共许可协议之一部分。

Creative Commons may be contacted at creativecommons.org. Creative Commons is the nonprofit behind the open licenses and other legal tools that allow creators to share their work. Our legal tools are free to use.